import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
  deleteDoc,
  getDocs,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { MenuItem } from '../types';
import { MENU_ITEMS } from '../data/menu';

const PRODUCTS_COLLECTION = 'products';

export function subscribeToProducts(
  onUpdate: (products: MenuItem[]) => void,
  onError?: (error: Error) => void
): () => void {
  const colRef = collection(db, PRODUCTS_COLLECTION);
  return onSnapshot(
    colRef,
    (snapshot) => {
      if (snapshot.empty) {
        // Fallback to initial local items while bootstrapping or if empty
        onUpdate(MENU_ITEMS.map((item) => ({ ...item, isAvailable: item.isAvailable ?? true })));
      } else {
        const items = snapshot.docs.map((docSnap) => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            name: data.name || '',
            category: data.category || 'classicas',
            description: data.description || '',
            price: Number(data.price) || 0,
            image: data.image || '',
            isAvailable: data.isAvailable !== false,
            highlight: Boolean(data.highlight),
            tags: data.tags || [],
          } as MenuItem;
        });
        onUpdate(items);
      }
    },
    (err) => {
      console.error('Error fetching products:', err);
      // Still show initial menu so public site never breaks
      onUpdate(MENU_ITEMS.map((item) => ({ ...item, isAvailable: true })));
      if (onError) onError(err);
    }
  );
}

export async function addProduct(
  data: Omit<MenuItem, 'id'> & { id?: string }
): Promise<string> {
  const id = data.id || 'prod_' + Date.now();
  const path = `${PRODUCTS_COLLECTION}/${id}`;
  try {
    await setDoc(doc(db, PRODUCTS_COLLECTION, id), {
      ...data,
      isAvailable: data.isAvailable !== false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateProduct(
  id: string,
  data: Partial<MenuItem>
): Promise<void> {
  const path = `${PRODUCTS_COLLECTION}/${id}`;
  try {
    await updateDoc(doc(db, PRODUCTS_COLLECTION, id), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function toggleProductAvailability(
  id: string,
  isAvailable: boolean
): Promise<void> {
  return updateProduct(id, { isAvailable });
}

export async function updateProductPrice(
  id: string,
  price: number
): Promise<void> {
  return updateProduct(id, { price });
}

export async function deleteProduct(id: string): Promise<void> {
  const path = `${PRODUCTS_COLLECTION}/${id}`;
  try {
    await deleteDoc(doc(db, PRODUCTS_COLLECTION, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
