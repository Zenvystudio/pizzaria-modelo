import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  getDocs,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { CategoryItem } from '../types';
import { DEFAULT_CATEGORIES } from './bootstrapService';

const CATEGORIES_COLLECTION = 'categories';

export function subscribeToCategories(
  onUpdate: (categories: CategoryItem[]) => void,
  onError?: (error: Error) => void
): () => void {
  const colRef = collection(db, CATEGORIES_COLLECTION);
  return onSnapshot(
    colRef,
    (snapshot) => {
      if (snapshot.empty) {
        onUpdate(DEFAULT_CATEGORIES);
      } else {
        const categories = snapshot.docs.map((docSnap) => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            name: data.name || '',
            description: data.description || '',
            order: Number(data.order) || 0,
            isActive: data.isActive !== false,
          } as CategoryItem;
        });
        categories.sort((a, b) => a.order - b.order);
        onUpdate(categories);
      }
    },
    (err) => {
      console.error('Error fetching categories:', err);
      onUpdate(DEFAULT_CATEGORIES);
      if (onError) onError(err);
    }
  );
}

export async function addCategory(
  data: Omit<CategoryItem, 'id'> & { id?: string }
): Promise<string> {
  const slug =
    data.id ||
    data.name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]/g, '_') +
      '_' +
      Date.now();
  const path = `${CATEGORIES_COLLECTION}/${slug}`;

  try {
    await setDoc(doc(db, CATEGORIES_COLLECTION, slug), {
      ...data,
      isActive: data.isActive !== false,
      createdAt: new Date().toISOString(),
    });
    return slug;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateCategory(
  id: string,
  data: Partial<CategoryItem>
): Promise<void> {
  const path = `${CATEGORIES_COLLECTION}/${id}`;
  try {
    await updateDoc(doc(db, CATEGORIES_COLLECTION, id), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteCategory(id: string): Promise<{ success: boolean; error?: string }> {
  // Check if any product is associated with this category
  const productsQuery = query(collection(db, 'products'), where('category', '==', id));
  const productsSnap = await getDocs(productsQuery);
  if (!productsSnap.empty) {
    return {
      success: false,
      error: `Não é possível excluir: existem ${productsSnap.size} produto(s) vinculados a esta categoria. Mova-os primeiro.`,
    };
  }

  const path = `${CATEGORIES_COLLECTION}/${id}`;
  try {
    await deleteDoc(doc(db, CATEGORIES_COLLECTION, id));
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
