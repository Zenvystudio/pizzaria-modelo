import {
  collection,
  doc,
  getDocs,
  setDoc,
} from 'firebase/firestore';
import { db } from '../firebase';
import { MENU_ITEMS } from '../data/menu';
import { PizzeriaSettings, CategoryItem } from '../types';

export const DEFAULT_SETTINGS: PizzeriaSettings = {
  pizzeriaName: 'Pizzaria',
  phone: '(00) 00000-0000',
  whatsapp: '(00) 00000-0000',
  address: 'Rua xxxxxxxxxxxxxx',
  defaultDeliveryFee: 8.0,
  estimatedDeliveryTime: '40–50 min',
  minimumOrder: 40.0,
  isOpen: true,
  closedMessage: 'No momento nosso forno está descansando. Abriremos em breve!',
  acceptedPayments: 'PIX, Cartão de Crédito, Débito e Dinheiro',
  instagram: '@pizzaria.artesanal',
  updatedAt: new Date().toISOString(),
};

export const DEFAULT_CATEGORIES: CategoryItem[] = [
  {
    id: 'classicas',
    name: 'Pizzas Clássicas',
    description: 'Receitas tradicionais de Nápoles com ingredientes nobres',
    order: 1,
    isActive: true,
  },
  {
    id: 'especiais',
    name: 'Pizzas Especiais',
    description: 'Combinações exclusivas do nosso mestre pizzaiolo',
    order: 2,
    isActive: true,
  },
  {
    id: 'bebidas',
    name: 'Bebidas & Vinhos',
    description: 'Vinhos italianos selecionados e bebidas especiais',
    order: 3,
    isActive: true,
  },
];

export async function bootstrapDatabaseIfEmpty(): Promise<void> {
  try {
    // 1. Seed settings if needed
    await setDoc(doc(db, 'settings', 'general'), DEFAULT_SETTINGS, { merge: true });

    // 2. Seed categories if empty
    const categoriesSnap = await getDocs(collection(db, 'categories'));
    if (categoriesSnap.empty) {
      for (const cat of DEFAULT_CATEGORIES) {
        await setDoc(doc(db, 'categories', cat.id), cat);
      }
    }

    // 3. Seed products if empty
    const productsSnap = await getDocs(collection(db, 'products'));
    if (productsSnap.empty) {
      for (const item of MENU_ITEMS) {
        await setDoc(doc(db, 'products', item.id), {
          ...item,
          isAvailable: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
      }
    }
  } catch (error) {
    console.warn('Bootstrap note:', error);
  }
}
