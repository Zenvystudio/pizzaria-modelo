import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  onSnapshot,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, auth } from '../firebase';
import { AuthorizedStaff, AdminUser } from '../types';

const AUTHORIZED_STAFF_COLLECTION = 'authorized_staff';
const ADMINS_COLLECTION = 'admins';

export function subscribeToAuthorizedStaff(
  onUpdate: (staffList: AuthorizedStaff[]) => void,
  onError?: (error: Error) => void
): () => void {
  const colRef = collection(db, AUTHORIZED_STAFF_COLLECTION);
  return onSnapshot(
    colRef,
    (snapshot) => {
      const list = snapshot.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          email: docSnap.id,
          name: d.name || '',
          role: d.role || 'staff',
          addedBy: d.addedBy || 'Administrador',
          createdAt: d.createdAt || new Date().toISOString(),
        } as AuthorizedStaff;
      });
      onUpdate(list);
    },
    (err) => {
      console.warn('Note on authorized_staff subscription:', err);
      if (onError) onError(err);
    }
  );
}

export async function authorizeNewStaff(params: {
  email: string;
  name?: string;
  role: 'admin' | 'staff';
}): Promise<void> {
  const normalizedEmail = params.email.trim().toLowerCase();
  const path = `${AUTHORIZED_STAFF_COLLECTION}/${normalizedEmail}`;

  const currentEmail = auth.currentUser?.email || 'proprietário';

  try {
    await setDoc(doc(db, AUTHORIZED_STAFF_COLLECTION, normalizedEmail), {
      email: normalizedEmail,
      name: params.name?.trim() || '',
      role: params.role,
      addedBy: currentEmail,
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function revokeStaffAccess(email: string, uid?: string): Promise<void> {
  const normalizedEmail = email.trim().toLowerCase();

  // 1. Delete from authorized_staff
  const authPath = `${AUTHORIZED_STAFF_COLLECTION}/${normalizedEmail}`;
  try {
    await deleteDoc(doc(db, AUTHORIZED_STAFF_COLLECTION, normalizedEmail));
  } catch (err) {
    console.warn('Error deleting from authorized_staff:', err);
  }

  // 2. If UID is provided, also delete from active admins collection
  if (uid) {
    const adminPath = `${ADMINS_COLLECTION}/${uid}`;
    try {
      await deleteDoc(doc(db, ADMINS_COLLECTION, uid));
    } catch (err) {
      console.warn('Error deleting active admin doc:', err);
    }
  } else {
    // Search by email in admins collection
    try {
      const snap = await getDocs(collection(db, ADMINS_COLLECTION));
      for (const d of snap.docs) {
        if (d.data().email?.toLowerCase() === normalizedEmail) {
          await deleteDoc(doc(db, ADMINS_COLLECTION, d.id));
        }
      }
    } catch (err) {
      console.warn('Error cleaning up active admin docs:', err);
    }
  }
}

export async function getActiveAdmins(): Promise<AdminUser[]> {
  try {
    const snap = await getDocs(collection(db, ADMINS_COLLECTION));
    return snap.docs.map((d) => d.data() as AdminUser);
  } catch {
    return [];
  }
}
