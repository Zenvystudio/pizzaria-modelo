import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
  query,
  orderBy,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Order, OrderStatus, PaymentStatus, CartItem, PizzeriaSettings } from '../types';

const ORDERS_COLLECTION = 'orders';

export function subscribeToOrders(
  onUpdate: (orders: Order[]) => void,
  onError?: (error: Error) => void
): () => void {
  const colRef = collection(db, ORDERS_COLLECTION);
  const q = query(colRef, orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const orders = snapshot.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          customerName: d.customerName || 'Cliente',
          customerPhone: d.customerPhone || '',
          items: d.items || [],
          subtotal: Number(d.subtotal) || 0,
          deliveryFee: Number(d.deliveryFee) || 0,
          discount: Number(d.discount) || 0,
          total: Number(d.total) || 0,
          orderType: d.orderType || 'entrega',
          deliveryAddress: d.deliveryAddress || '',
          notes: d.notes || '',
          paymentMethod: d.paymentMethod || 'pix',
          paymentStatus: d.paymentStatus || 'pendente',
          status: d.status || 'novo',
          createdAt: d.createdAt || new Date().toISOString(),
          updatedAt: d.updatedAt || new Date().toISOString(),
        } as Order;
      });
      onUpdate(orders);
    },
    (err) => {
      console.error('Error listening to orders:', err);
      if (onError) onError(err);
    }
  );
}

export async function createOrderFromCart(params: {
  customerName: string;
  customerPhone: string;
  items: CartItem[];
  orderType: 'entrega' | 'retirada' | 'mesa';
  deliveryAddress?: string;
  notes?: string;
  paymentMethod: 'pix' | 'cartao_credito' | 'cartao_debito' | 'dinheiro';
  settings?: PizzeriaSettings;
}): Promise<{ order: Order; whatsappUrl: string }> {
  // Generate concise human-friendly tracking code
  const code = 'PZ-' + Math.floor(1000 + Math.random() * 9000);
  const now = new Date().toISOString();

  // Validate items and compute subtotal
  const orderItems = params.items.map((ci) => ({
    id: ci.item.id,
    name: ci.item.name,
    price: Number(ci.item.price),
    quantity: Number(ci.quantity),
    notes: ci.notes || '',
  }));

  const subtotal = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = params.orderType === 'entrega' ? (params.settings?.defaultDeliveryFee ?? 8) : 0;
  const total = subtotal + deliveryFee;

  const orderData: Order = {
    id: code,
    customerName: params.customerName.trim(),
    customerPhone: params.customerPhone.trim(),
    items: orderItems,
    subtotal,
    deliveryFee,
    discount: 0,
    total,
    orderType: params.orderType,
    deliveryAddress: params.deliveryAddress?.trim() || '',
    notes: params.notes?.trim() || '',
    paymentMethod: params.paymentMethod,
    paymentStatus: 'pendente',
    status: 'novo',
    createdAt: now,
    updatedAt: now,
  };

  const path = `${ORDERS_COLLECTION}/${code}`;
  try {
    await setDoc(doc(db, ORDERS_COLLECTION, code), orderData);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }

  // Format WhatsApp message
  const itemsText = orderItems
    .map((item) => `• ${item.quantity}x ${item.name} (R$ ${(item.price * item.quantity).toFixed(2).replace('.', ',')})`)
    .join('%0A');

  const paymentLabel = {
    pix: 'PIX',
    cartao_credito: 'Cartão de Crédito',
    cartao_debito: 'Cartão de Débito',
    dinheiro: 'Dinheiro',
  }[params.paymentMethod];

  const orderTypeLabel = {
    entrega: 'Entrega Delivery',
    retirada: 'Retirada no Balcão',
    mesa: 'Consumo no Salão',
  }[params.orderType];

  let text = `🍕 *NOVO PEDIDO #${code} - PIZZARIA*%0A%0A`;
  text += `👤 *Cliente:* ${encodeURIComponent(orderData.customerName)}%0A`;
  text += `📱 *Telefone:* ${encodeURIComponent(orderData.customerPhone)}%0A`;
  text += `📍 *Modalidade:* ${orderTypeLabel}%0A`;
  if (orderData.deliveryAddress) {
    text += `🏠 *Endereço:* ${encodeURIComponent(orderData.deliveryAddress)}%0A`;
  }
  text += `💳 *Forma de Pagamento:* ${paymentLabel}%0A%0A`;
  text += `📋 *Itens Selecionados:*%0A${itemsText}%0A%0A`;
  if (deliveryFee > 0) {
    text += `Subtotal: R$ ${subtotal.toFixed(2).replace('.', ',')}%0A`;
    text += `Taxa de Entrega: R$ ${deliveryFee.toFixed(2).replace('.', ',')}%0A`;
  }
  text += `💰 *TOTAL:* R$ ${total.toFixed(2).replace('.', ',')}%0A`;
  if (orderData.notes) {
    text += `%0A📝 *Observações:* ${encodeURIComponent(orderData.notes)}%0A`;
  }
  text += `%0APor favor, confirmem o recebimento do pedido #${code}.`;

  // Use sanitized phone
  const rawPhone = params.settings?.whatsapp || '5500000000000';
  const cleanPhone = rawPhone.replace(/\D/g, '') || '5500000000000';
  const finalPhone = cleanPhone.startsWith('55') ? cleanPhone : '55' + cleanPhone;

  const whatsappUrl = `https://wa.me/${finalPhone}?text=${text}`;

  return { order: orderData, whatsappUrl };
}

export async function updateOrderStatus(orderId: string, status: OrderStatus): Promise<void> {
  const path = `${ORDERS_COLLECTION}/${orderId}`;
  try {
    await updateDoc(doc(db, ORDERS_COLLECTION, orderId), {
      status,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updateOrderPaymentStatus(orderId: string, paymentStatus: PaymentStatus): Promise<void> {
  const path = `${ORDERS_COLLECTION}/${orderId}`;
  try {
    await updateDoc(doc(db, ORDERS_COLLECTION, orderId), {
      paymentStatus,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}
