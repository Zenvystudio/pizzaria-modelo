import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { PizzeriaSettings } from '../types';
import { DEFAULT_SETTINGS } from './bootstrapService';

const SETTINGS_DOC = 'settings/general';

export function subscribeToSettings(
  onUpdate: (settings: PizzeriaSettings) => void,
  onError?: (error: Error) => void
): () => void {
  const docRef = doc(db, 'settings', 'general');
  return onSnapshot(
    docRef,
    (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        onUpdate({
          pizzeriaName: data.pizzeriaName || DEFAULT_SETTINGS.pizzeriaName,
          phone: data.phone || DEFAULT_SETTINGS.phone,
          whatsapp: data.whatsapp || DEFAULT_SETTINGS.whatsapp,
          address: data.address || DEFAULT_SETTINGS.address,
          defaultDeliveryFee: Number(data.defaultDeliveryFee ?? DEFAULT_SETTINGS.defaultDeliveryFee),
          estimatedDeliveryTime: data.estimatedDeliveryTime || DEFAULT_SETTINGS.estimatedDeliveryTime,
          minimumOrder: Number(data.minimumOrder ?? DEFAULT_SETTINGS.minimumOrder),
          isOpen: data.isOpen !== false,
          closedMessage: data.closedMessage || DEFAULT_SETTINGS.closedMessage,
          acceptedPayments: data.acceptedPayments || DEFAULT_SETTINGS.acceptedPayments,
          instagram: data.instagram || DEFAULT_SETTINGS.instagram,
          updatedAt: data.updatedAt || new Date().toISOString(),
        });
      } else {
        onUpdate(DEFAULT_SETTINGS);
      }
    },
    (err) => {
      console.warn('Error reading settings, using defaults:', err);
      onUpdate(DEFAULT_SETTINGS);
      if (onError) onError(err);
    }
  );
}

export async function updatePizzeriaSettings(
  data: Partial<PizzeriaSettings>
): Promise<void> {
  try {
    await setDoc(
      doc(db, 'settings', 'general'),
      {
        ...data,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, SETTINGS_DOC);
  }
}
