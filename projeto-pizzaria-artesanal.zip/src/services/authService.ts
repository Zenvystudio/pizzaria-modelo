import { AdminUser } from '../types';

const TOKEN_KEY = 'pizzaria_admin_session_token';

let authListeners: Array<(user: AdminUser | null) => void> = [];

function notifyListeners(user: AdminUser | null) {
  authListeners.forEach((fn) => fn(user));
}

/**
 * Validates panel password against the secure backend /api/admin/login.
 * Does not expose credentials, comparison or password hashes in client JavaScript.
 */
export async function loginWithPassword(password: string): Promise<AdminUser> {
  const cleanPassword = password.trim();

  const response = await fetch('/api/admin/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      password: cleanPassword,
    }),
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok || !data.success) {
    throw new Error(data.error || 'Senha incorreta. Tente novamente');
  }

  // Store secure session token in sessionStorage (isolated to current browser session)
  sessionStorage.setItem(TOKEN_KEY, data.token);

  const adminUser: AdminUser = {
    uid: 'panel_admin_session',
    email: 'administracao@pizzaria.local',
    role: 'admin',
    name: 'Funcionário Autorizado',
  };

  notifyListeners(adminUser);
  return adminUser;
}

/**
 * Checks if there is an active validated session on the backend.
 */
export async function checkAdminSession(): Promise<AdminUser | null> {
  const token = sessionStorage.getItem(TOKEN_KEY);
  if (!token) return null;

  try {
    const res = await fetch('/api/admin/session', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!res.ok) {
      sessionStorage.removeItem(TOKEN_KEY);
      notifyListeners(null);
      return null;
    }

    const data = await res.json();
    if (data.authenticated) {
      const user: AdminUser = {
        uid: 'panel_admin_session',
        email: 'administracao@pizzaria.local',
        role: 'admin',
        name: data.user?.name || 'Funcionário Autorizado',
      };
      notifyListeners(user);
      return user;
    }

    sessionStorage.removeItem(TOKEN_KEY);
    notifyListeners(null);
    return null;
  } catch (err) {
    console.warn('Session verification warning:', err);
    return null;
  }
}

/**
 * Changes the admin panel access password via /api/admin/change-password.
 * Requires authPassword ('senha123') and matching new passwords.
 */
export async function changePanelPassword(
  authPassword: string,
  newPassword: string,
  confirmPassword: string
): Promise<{ success: boolean; message: string }> {
  const token = sessionStorage.getItem(TOKEN_KEY);
  if (!token) {
    throw new Error('Sessão expirada. Faça login novamente no painel.');
  }

  const response = await fetch('/api/admin/change-password', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      authPassword: authPassword.trim(),
      newPassword: newPassword.trim(),
      confirmPassword: confirmPassword.trim(),
    }),
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok || !data.success) {
    throw new Error(data.error || 'Erro ao alterar a senha do painel.');
  }

  return {
    success: true,
    message: data.message || 'Senha alterada com sucesso!',
  };
}

/**
 * Terminates the employee session on the backend and in the browser.
 */
export async function logout(): Promise<void> {
  const token = sessionStorage.getItem(TOKEN_KEY);
  if (token) {
    try {
      await fetch('/api/admin/logout', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    } catch {
      // ignore network errors on logout
    }
  }

  sessionStorage.removeItem(TOKEN_KEY);
  notifyListeners(null);
}

/**
 * Subscribes to authentication state changes.
 */
export function subscribeToAuth(
  callback: (adminUser: AdminUser | null) => void
): () => void {
  authListeners.push(callback);

  // Initial check
  checkAdminSession().then((user) => {
    callback(user);
  });

  return () => {
    authListeners = authListeners.filter((fn) => fn !== callback);
  };
}
