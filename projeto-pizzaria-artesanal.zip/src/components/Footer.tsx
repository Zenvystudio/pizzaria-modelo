import React from 'react';
import { Lock } from 'lucide-react';

interface FooterProps {
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin }) => {
  return (
    <footer className="w-full bg-secondary border-t border-surface-border py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="flex flex-col md:flex-row items-center gap-6">
          <a
            href="#inicio"
            className="font-display text-2xl font-bold tracking-tight text-foreground hover:text-primary transition-colors whitespace-nowrap"
          >
            Pizzaria
          </a>
          <span className="hidden md:inline text-surface-border">|</span>
          <p className="text-xs text-muted text-center md:text-left">
            Tradição artesanal napolitana assada a lenha.
          </p>
        </div>

        <nav className="flex flex-wrap justify-center items-center gap-6 text-xs text-muted">
          <a href="#cardapio" className="hover:text-foreground transition-colors whitespace-nowrap">
            Cardápio
          </a>
          <a href="#tradicao" className="hover:text-foreground transition-colors whitespace-nowrap">
            Nossa Tradição
          </a>
          <a href="#localizacao" className="hover:text-foreground transition-colors whitespace-nowrap">
            Localização
          </a>
          <a href="#contato" className="hover:text-foreground transition-colors whitespace-nowrap">
            Contato
          </a>

          {/* Discreet Admin Entrance for staff */}
          <button
            onClick={() => {
              if (onOpenAdmin) {
                onOpenAdmin();
              } else {
                window.location.hash = 'admin';
              }
            }}
            className="inline-flex items-center gap-1.5 text-[11px] font-mono text-muted/60 hover:text-primary transition-colors cursor-pointer"
            title="Painel Administrativo da Pizzaria"
          >
            <Lock className="w-3 h-3" />
            <span>Área do Funcionário</span>
          </button>
        </nav>

        <div className="text-xs text-muted/70 font-mono">
          © {new Date().getFullYear()} Pizzaria. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
};
