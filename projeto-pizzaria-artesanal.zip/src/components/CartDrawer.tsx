import React, { useState } from 'react';
import { X, Plus, Minus, ShoppingBag, Send, AlertCircle, CheckCircle2 } from 'lucide-react';
import { CartItem, PizzeriaSettings, Order } from '../types';
import { createOrderFromCart } from '../services/orderService';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onClearCart: () => void;
  settings: PizzeriaSettings;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onClearCart,
  settings,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [orderType, setOrderType] = useState<'entrega' | 'retirada' | 'mesa'>('entrega');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'cartao_credito' | 'cartao_debito' | 'dinheiro'>('pix');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.item.price * item.quantity, 0);
  const deliveryFee = orderType === 'entrega' ? settings.defaultDeliveryFee : 0;
  const total = subtotal + deliveryFee;

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (items.length === 0) {
      setError('Seu pedido está vazio.');
      return;
    }

    if (!settings.isOpen) {
      setError(settings.closedMessage || 'A pizzaria está fechada no momento.');
      return;
    }

    // Check item availability
    const unavailableItem = items.find((i) => i.item.isAvailable === false);
    if (unavailableItem) {
      setError(`O item "${unavailableItem.item.name}" não está mais disponível.`);
      return;
    }

    if (!customerName.trim()) {
      setError('Por favor, informe seu nome.');
      return;
    }

    if (!customerPhone.trim() || customerPhone.replace(/\D/g, '').length < 8) {
      setError('Por favor, informe um telefone/WhatsApp válido com DDD.');
      return;
    }

    if (orderType === 'entrega' && !deliveryAddress.trim()) {
      setError('Por favor, informe o endereço de entrega completo.');
      return;
    }

    if (subtotal < settings.minimumOrder) {
      setError(`O valor mínimo do pedido é de R$ ${settings.minimumOrder.toFixed(2).replace('.', ',')}.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const { order, whatsappUrl } = await createOrderFromCart({
        customerName,
        customerPhone,
        items,
        orderType,
        deliveryAddress,
        notes,
        paymentMethod,
        settings,
      });

      setCreatedOrder(order);
      onClearCart();

      // Open WhatsApp in a new tab
      window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    } catch (err: any) {
      console.error(err);
      setError('Ocorreu um erro ao registrar o pedido. Tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-lg bg-secondary border-l border-surface-border p-6 flex flex-col justify-between shadow-2xl overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between pb-5 border-b border-surface-border shrink-0">
            <div className="flex items-center gap-3">
              <ShoppingBag className="w-5 h-5 text-primary" />
              <h3 className="font-display text-xl font-bold text-foreground">
                Seu Pedido
              </h3>
            </div>
            <button
              onClick={() => {
                setCreatedOrder(null);
                onClose();
              }}
              className="p-2 text-muted hover:text-foreground transition-colors rounded-lg cursor-pointer"
              aria-label="Fechar resumo do pedido"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Success Screen if order placed */}
          {createdOrder ? (
            <div className="flex-1 py-12 text-center space-y-6">
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <span className="font-mono text-xs text-muted uppercase">Pedido Confirmado no Sistema</span>
                <h4 className="font-display text-2xl font-bold text-foreground">
                  #{createdOrder.id}
                </h4>
                <p className="text-xs text-muted max-w-sm mx-auto leading-relaxed">
                  Seu pedido foi registrado no sistema da pizzaria e a conversa no WhatsApp foi aberta para confirmação.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-surface border border-surface-border text-left text-xs space-y-2 font-mono">
                <div className="flex justify-between">
                  <span className="text-muted">Total:</span>
                  <span className="font-bold text-foreground">R$ {createdOrder.total.toFixed(2).replace('.', ',')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted">Status:</span>
                  <span className="text-primary font-bold uppercase">{createdOrder.status}</span>
                </div>
              </div>

              <button
                onClick={() => {
                  setCreatedOrder(null);
                  onClose();
                }}
                className="w-full py-3.5 rounded-lg bg-surface-hover hover:bg-secondary text-foreground text-xs font-semibold uppercase tracking-wider border border-surface-border cursor-pointer transition-colors"
              >
                Continuar Navegando
              </button>
            </div>
          ) : (
            <div className="flex-1 flex flex-col justify-between py-6 space-y-6">
              {/* Items list */}
              <div className="space-y-3">
                <div className="text-xs font-mono uppercase text-muted tracking-wider">
                  Itens Selecionados ({items.length})
                </div>

                {items.length === 0 ? (
                  <div className="text-center py-12 space-y-2">
                    <ShoppingBag className="w-8 h-8 text-muted mx-auto stroke-1" />
                    <p className="text-muted text-xs">Nenhum item selecionado.</p>
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                    {items.map((cartItem) => (
                      <div
                        key={cartItem.item.id}
                        className="p-3.5 rounded-xl bg-surface border border-surface-border flex items-center justify-between gap-3 text-xs"
                      >
                        <div className="space-y-0.5">
                          <h5 className="font-semibold text-foreground">
                            {cartItem.item.name}
                          </h5>
                          <div className="font-mono text-muted text-[11px] tabular-nums">
                            R$ {cartItem.item.price.toFixed(2).replace('.', ',')}
                          </div>
                        </div>

                        <div className="flex items-center gap-2.5">
                          <div className="flex items-center bg-secondary rounded-lg border border-surface-border p-0.5">
                            <button
                              onClick={() => onUpdateQuantity(cartItem.item.id, -1)}
                              className="p-1 hover:text-primary transition-colors cursor-pointer"
                              aria-label="Diminuir"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-6 text-center font-mono text-xs font-semibold tabular-nums text-foreground">
                              {cartItem.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(cartItem.item.id, 1)}
                              className="p-1 hover:text-primary transition-colors cursor-pointer"
                              aria-label="Aumentar"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <div className="font-mono font-bold text-foreground w-16 text-right tabular-nums">
                            R$ {(cartItem.item.price * cartItem.quantity).toFixed(2).replace('.', ',')}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Checkout Form */}
              {items.length > 0 && (
                <form onSubmit={handleCheckout} className="space-y-4 pt-2 border-t border-surface-border">
                  <div className="text-xs font-mono uppercase text-muted tracking-wider">
                    Dados para Entrega & WhatsApp
                  </div>

                  {error && (
                    <div className="p-3 rounded-lg bg-primary/10 border border-primary/30 flex items-start gap-2 text-xs text-primary">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{error}</span>
                    </div>
                  )}

                  {/* Order Type Tabs */}
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'entrega', label: 'Delivery' },
                      { id: 'retirada', label: 'Balcão' },
                      { id: 'mesa', label: 'Mesa' },
                    ].map((type) => (
                      <button
                        key={type.id}
                        type="button"
                        onClick={() => setOrderType(type.id as any)}
                        className={`py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                          orderType === type.id
                            ? 'bg-primary text-white border-primary shadow-sm'
                            : 'bg-surface text-muted border-surface-border hover:text-foreground'
                        }`}
                      >
                        {type.label}
                      </button>
                    ))}
                  </div>

                  {/* Name and Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] font-medium text-foreground">Seu Nome *</label>
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Ex: Ana Silva"
                        required
                        className="w-full px-3 py-2 rounded-lg bg-surface border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-medium text-foreground">WhatsApp (com DDD) *</label>
                      <input
                        type="tel"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="Ex: (11) 98765-4321"
                        required
                        className="w-full px-3 py-2 rounded-lg bg-surface border border-surface-border text-foreground text-xs font-mono focus:outline-none focus:border-primary"
                      />
                    </div>
                  </div>

                  {/* Delivery Address if Delivery */}
                  {orderType === 'entrega' && (
                    <div className="space-y-1">
                      <label className="text-[11px] font-medium text-foreground">Endereço de Entrega Completo *</label>
                      <input
                        type="text"
                        value={deliveryAddress}
                        onChange={(e) => setDeliveryAddress(e.target.value)}
                        placeholder="Rua, número, complemento, bairro..."
                        required
                        className="w-full px-3 py-2 rounded-lg bg-surface border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary"
                      />
                    </div>
                  )}

                  {/* Payment Method */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-foreground">Forma de Pagamento</label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-lg bg-surface border border-surface-border text-foreground text-xs font-semibold focus:outline-none focus:border-primary"
                    >
                      <option value="pix">PIX (Chave Instantânea)</option>
                      <option value="cartao_credito">Cartão de Crédito na Entrega</option>
                      <option value="cartao_debito">Cartão de Débito na Entrega</option>
                      <option value="dinheiro">Dinheiro (Informar troco em observações)</option>
                    </select>
                  </div>

                  {/* Notes */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-foreground">Observações (opcional)</label>
                    <input
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Sem cebola, massa bem crocante, troco para 100..."
                      className="w-full px-3 py-2 rounded-lg bg-surface border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary"
                    />
                  </div>

                  {/* Totals Summary */}
                  <div className="pt-3 border-t border-surface-border space-y-1.5 text-xs font-mono">
                    <div className="flex justify-between text-muted">
                      <span>Subtotal:</span>
                      <span>R$ {subtotal.toFixed(2).replace('.', ',')}</span>
                    </div>
                    {deliveryFee > 0 && (
                      <div className="flex justify-between text-muted">
                        <span>Taxa de Entrega:</span>
                        <span>R$ {deliveryFee.toFixed(2).replace('.', ',')}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm font-bold text-foreground pt-1.5 border-t border-surface-border/50">
                      <span>Total Geral:</span>
                      <span className="text-primary text-base">R$ {total.toFixed(2).replace('.', ',')}</span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 px-6 rounded-md bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-widest font-semibold flex items-center justify-center gap-3 transition-colors shadow-lg shadow-primary/20 cursor-pointer disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isSubmitting ? 'Registrando Pedido...' : 'Enviar Pedido para WhatsApp'}</span>
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
