import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Flame } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <section
      id="inicio"
      className="relative min-h-[92vh] flex flex-col justify-center px-6 pt-12 pb-20 overflow-hidden bg-background"
    >
      {/* Subtle radial ambient warmth centered behind the hero */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-primary/10 rounded-full blur-[140px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        {/* Left Column: Bold, refined typography with generous breathing space */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-6 flex flex-col justify-center space-y-8"
        >
          {/* Natural quiet kicker */}
          <div className="flex items-center gap-3 text-xs tracking-[0.25em] uppercase text-muted font-medium">
            <span className="text-primary font-bold">Tradição Italiana</span>
            <span aria-hidden="true" className="text-surface-border">/</span>
            <span>Desde 2008</span>
          </div>

          {/* Huge confident display title */}
          <h1
            className="font-display font-bold text-foreground text-balance tracking-tight leading-[1.06]"
            style={{ fontSize: 'clamp(2.75rem, 5.5vw, 4.75rem)' }}
          >
            Fogo a lenha e perfeição artesanal.
          </h1>

          {/* Strict single concise supporting sentence */}
          <p className="text-lg md:text-xl text-muted font-normal leading-relaxed max-w-xl text-balance">
            Massa de fermentação lenta por 48 horas, farinha italiana pura e o calor vivo da brasa na temperatura exata.
          </p>

          {/* Action block */}
          <div className="flex flex-wrap items-center gap-4 pt-2">
            <a
              href="#contato"
              className="inline-flex items-center gap-3 px-8 py-4 text-xs md:text-sm uppercase tracking-widest font-semibold text-white bg-primary hover:bg-primary-hover rounded-md transition-all duration-200 shadow-lg shadow-primary/20 group cursor-pointer whitespace-nowrap"
            >
              <span>Entrar em contato</span>
              <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
            </a>

            <a
              href="#cardapio"
              className="inline-flex items-center px-7 py-4 text-xs md:text-sm uppercase tracking-widest font-semibold text-foreground/80 hover:text-foreground bg-surface hover:bg-surface-hover border border-surface-border rounded-md transition-colors whitespace-nowrap cursor-pointer"
            >
              Ver Cardápio
            </a>
          </div>

          {/* Proof note: quiet unboxed typography */}
          <div className="pt-4 flex items-center gap-6 text-xs text-muted">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-primary" />
              <span>Forno a 450°C</span>
            </div>
            <span aria-hidden="true" className="text-surface-border">·</span>
            <div>Farinha Tipo 00 Importada</div>
            <span aria-hidden="true" className="text-surface-border">·</span>
            <div>San Marzano D.O.P.</div>
          </div>
        </motion.div>

        {/* Right Column: Hero High-Impact Visual Asset */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-6 relative"
        >
          <div className="relative mx-auto rounded-2xl overflow-hidden border border-surface-border shadow-2xl bg-surface">
            {/* Scrim overlay for photographic depth */}
            <div
              className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent pointer-events-none z-10"
              aria-hidden="true"
            />
            <img
              src="/src/assets/images/hero_artisanal_pizza_1792635816049.jpg"
              alt="Pizza artesanal napolitana assada saindo do forno a lenha com brasas vivas"
              className="w-full h-[460px] md:h-[540px] object-cover object-center transition-transform duration-700 hover:scale-[1.02]"
              referrerPolicy="no-referrer"
              loading="eager"
            />
            {/* Elegant quiet photo caption badge */}
            <div className="absolute bottom-5 left-6 right-6 z-20 flex items-center justify-between text-xs text-foreground/90 backdrop-blur-md bg-secondary/80 px-4 py-2.5 rounded-lg border border-surface-border">
              <span className="font-medium">Assada em forno a lenha clássico</span>
              <span className="font-mono tabular-nums text-muted text-[11px]">90 Segundos / 450°C</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Gentle scroll indicator inviting to next section */}
      <div className="mt-12 text-center">
        <a
          href="#cardapio"
          className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-muted/80 hover:text-foreground transition-colors"
        >
          <span>Descubra as Criações</span>
          <span className="animate-bounce inline-block text-primary">↓</span>
        </a>
      </div>
    </section>
  );
};
