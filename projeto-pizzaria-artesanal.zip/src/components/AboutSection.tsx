import React from 'react';
import { motion } from 'motion/react';

export const AboutSection: React.FC = () => {
  return (
    <section id="tradicao" className="py-28 px-6 bg-background relative overflow-hidden">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        {/* Left Column: Atmospheric Interior & Oven Photo */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="lg:col-span-6 relative order-2 lg:order-1"
        >
          <div className="relative rounded-2xl overflow-hidden border border-surface-border shadow-2xl bg-surface">
            <img
              src="/src/assets/images/pizzeria_interior_oven_1792635817486.jpg"
              alt="Salão da pizzaria com forno a lenha clássico em tijolos aparentes e luz acolhedora"
              className="w-full h-[420px] md:h-[480px] object-cover object-center"
              referrerPolicy="no-referrer"
              loading="lazy"
            />
            <div
              className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent pointer-events-none"
              aria-hidden="true"
            />
            <div className="absolute bottom-6 left-6 right-6">
              <p className="text-xs uppercase tracking-widest text-muted/90 font-mono">
                Ambiente intimista & Forno à vista
              </p>
            </div>
          </div>
        </motion.div>

        {/* Right Column: Editorial story & Tabular stats */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="lg:col-span-6 space-y-10 order-1 lg:order-2"
        >
          <div className="space-y-4">
            <div className="text-xs uppercase tracking-[0.25em] text-primary font-bold">
              Nossa Tradição
            </div>
            <h2
              className="font-display font-bold text-foreground text-balance tracking-tight leading-[1.12]"
              style={{ fontSize: 'clamp(2.25rem, 4vw, 3.25rem)' }}
            >
              Farinha, água, fogo e respeito ao tempo.
            </h2>
          </div>

          <p className="text-muted text-base md:text-lg leading-relaxed max-w-xl text-balance">
            Nascemos com um propósito inegociável: honrar a verdadeira arte napolitana.
            Nossa massa fermenta lentamente por 48 horas em temperatura controlada,
            garantindo leveza digestiva, bordas infladas e crocância incomparável.
          </p>

          {/* Proof Strip: Quantitative Rigor with tabular figures */}
          <div className="pt-6 border-t border-surface-border grid grid-cols-3 gap-6">
            <div className="space-y-1">
              <div className="font-display text-3xl md:text-4xl font-bold text-foreground font-mono tabular-nums">
                18
              </div>
              <div className="text-xs text-muted leading-tight">
                Anos de tradição e fornos acesos
              </div>
            </div>

            <div className="space-y-1">
              <div className="font-display text-3xl md:text-4xl font-bold text-foreground font-mono tabular-nums">
                4.2k
              </div>
              <div className="text-xs text-muted leading-tight">
                Pizzas artesanais assadas por mês
              </div>
            </div>

            <div className="space-y-1">
              <div className="font-display text-3xl md:text-4xl font-bold text-primary font-mono tabular-nums">
                4.9★
              </div>
              <div className="text-xs text-muted leading-tight">
                Avaliação média em excelência
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
