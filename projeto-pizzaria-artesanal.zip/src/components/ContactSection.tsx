import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Phone, MessageCircle, Send, CheckCircle2 } from 'lucide-react';
import { PizzeriaSettings } from '../types';

interface ContactSectionProps {
  settings?: PizzeriaSettings;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ settings }) => {
  const [name, setName] = useState('');
  const [orderType, setOrderType] = useState<'pedido' | 'reserva'>('pedido');
  const [details, setDetails] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const phoneDisplay = settings?.phone || '(00) 00000-0000';
  const rawWhatsapp = settings?.whatsapp || '5500000000000';
  const cleanPhone = rawWhatsapp.replace(/\D/g, '') || '5500000000000';
  const finalPhone = cleanPhone.startsWith('55') ? cleanPhone : '55' + cleanPhone;

  const whatsappUrl = `https://wa.me/${finalPhone}?text=Ol%C3%A1%2C%20gostaria%20de%20falar%20com%20a%20Pizzaria.`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Por favor, informe seu nome.');
      return;
    }
    setError('');

    const message = `Olá! Meu nome é ${name}.%0A%0AEstou entrando em contato para: ${
      orderType === 'pedido' ? 'Fazer um pedido' : 'Fazer uma reserva de mesa'
    }.%0A%0ADetalhes: ${encodeURIComponent(details || 'Gostaria de mais informações.')}`;

    const link = `https://wa.me/${finalPhone}?text=${message}`;
    window.open(link, '_blank', 'noopener,noreferrer');
    setSubmitted(true);
  };

  return (
    <section id="contato" className="py-28 px-6 bg-background border-t border-surface-border">
      <div className="max-w-7xl mx-auto space-y-16">
        <div className="text-center max-w-xl mx-auto space-y-3">
          <div className="text-xs uppercase tracking-[0.25em] text-primary font-bold">
            Atendimento Exclusivo
          </div>
          <h2
            className="font-display font-bold text-foreground text-balance tracking-tight"
            style={{ fontSize: 'clamp(2.25rem, 4.5vw, 3.5rem)' }}
          >
            Entrar em Contato
          </h2>
          <p className="text-muted text-base leading-relaxed">
            Fale conosco diretamente para pedidos imediatos, reservas de mesa ou dúvidas sobre o cardápio.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 max-w-5xl mx-auto items-stretch">
          {/* Direct Contact Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-5 rounded-2xl bg-surface border border-surface-border p-8 md:p-10 flex flex-col justify-between space-y-8"
          >
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="text-xs font-mono uppercase tracking-widest text-muted">
                  Canal Direto
                </div>
                <h3 className="font-display text-2xl font-bold text-foreground">
                  Fale Conosco
                </h3>
                <p className="text-sm text-muted leading-relaxed">
                  Nosso atendimento no WhatsApp responde prontamente para agilizar seu pedido de fornada.
                </p>
              </div>

              <div className="space-y-4 pt-2">
                <div className="p-4 rounded-xl bg-secondary border border-surface-border flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/20 text-primary flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-muted font-mono uppercase">Telefone</div>
                    <div className="font-mono text-foreground font-semibold text-base">
                      {phoneDisplay}
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-secondary border border-surface-border flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-muted font-mono uppercase">WhatsApp Oficial</div>
                    <div className="font-mono text-foreground font-semibold text-base">
                      {settings?.whatsapp || phoneDisplay}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-4 px-6 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-xs uppercase tracking-widest font-semibold flex items-center justify-center gap-3 transition-colors shadow-lg shadow-emerald-900/30 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Conversar no WhatsApp</span>
            </a>
          </motion.div>

          {/* Interactive Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="lg:col-span-7 rounded-2xl bg-surface border border-surface-border p-8 md:p-10 shadow-xl flex flex-col justify-between"
          >
            {submitted ? (
              <div className="py-16 text-center space-y-4">
                <CheckCircle2 className="w-12 h-12 text-primary mx-auto" />
                <h3 className="font-display text-2xl font-bold text-foreground">
                  Solicitação Encaminhada
                </h3>
                <p className="text-sm text-muted max-w-sm mx-auto">
                  Sua mensagem foi formatada e aberta no WhatsApp para confirmação imediata.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-4 px-6 py-2.5 rounded-md text-xs font-semibold uppercase tracking-wider bg-surface-hover text-foreground border border-surface-border transition-colors cursor-pointer"
                >
                  Enviar outra mensagem
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <h3 className="font-display text-2xl font-bold text-foreground mb-1">
                    Envie sua Solicitação
                  </h3>
                  <p className="text-xs text-muted">
                    Preencha os dados e abra a conversa pronta no WhatsApp.
                  </p>
                </div>

                {error && (
                  <div className="p-3 rounded-lg bg-primary/10 border border-primary/30 text-xs text-primary font-medium">
                    {error}
                  </div>
                )}

                {/* Form Type Segmented Selector */}
                <div className="space-y-2">
                  <label className="block text-xs font-medium text-foreground">
                    Objetivo do Contato
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setOrderType('pedido')}
                      className={`py-2.5 px-4 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        orderType === 'pedido'
                          ? 'bg-primary text-white border border-primary'
                          : 'bg-secondary text-muted border border-surface-border hover:text-foreground'
                      }`}
                    >
                      Fazer Pedido
                    </button>
                    <button
                      type="button"
                      onClick={() => setOrderType('reserva')}
                      className={`py-2.5 px-4 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        orderType === 'reserva'
                          ? 'bg-primary text-white border border-primary'
                          : 'bg-secondary text-muted border border-surface-border hover:text-foreground'
                      }`}
                    >
                      Reservar Mesa
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="user-name" className="block text-xs font-medium text-foreground">
                    Seu Nome Completo
                  </label>
                  <input
                    id="user-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Gabriel Rossi"
                    className="w-full px-4 py-3 rounded-lg bg-secondary border border-surface-border text-foreground text-sm focus:outline-none focus:border-primary transition-colors"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="user-details" className="block text-xs font-medium text-foreground">
                    {orderType === 'pedido'
                      ? 'Pizzas desejadas ou observações'
                      : 'Data, horário e número de pessoas'}
                  </label>
                  <textarea
                    id="user-details"
                    rows={4}
                    value={details}
                    onChange={(e) => setDetails(e.target.value)}
                    placeholder={
                      orderType === 'pedido'
                        ? 'Ex: 1x Margherita e 1x Pepperoni para entrega no centro...'
                        : 'Ex: Mesa para 4 pessoas nesta sexta-feira às 20h...'
                    }
                    className="w-full px-4 py-3 rounded-lg bg-secondary border border-surface-border text-foreground text-sm focus:outline-none focus:border-primary transition-colors resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 px-6 rounded-md bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-widest font-semibold flex items-center justify-center gap-2 transition-colors shadow-lg shadow-primary/25 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Enviar para WhatsApp</span>
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};
