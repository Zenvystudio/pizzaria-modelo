import React, { useState } from 'react';
import { Menu, X, ShoppingBag } from 'lucide-react';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ cartCount, onOpenCart }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-secondary/90 border-b border-surface-border transition-colors">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#inicio"
          className="font-display text-2xl md:text-3xl font-bold tracking-tight text-foreground hover:text-primary transition-colors whitespace-nowrap shrink-0"
        >
          Pizzaria
        </a>

        {/* Zone 2: 4 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-muted">
          <a
            href="#cardapio"
            className="hover:text-foreground transition-colors whitespace-nowrap shrink-0"
          >
            Cardápio
          </a>
          <a
            href="#tradicao"
            className="hover:text-foreground transition-colors whitespace-nowrap shrink-0"
          >
            Nossa Tradição
          </a>
          <a
            href="#localizacao"
            className="hover:text-foreground transition-colors whitespace-nowrap shrink-0"
          >
            Localização
          </a>
          <a
            href="#contato"
            className="hover:text-foreground transition-colors whitespace-nowrap shrink-0"
          >
            Contato
          </a>
        </nav>

        {/* Zone 3: 1 primary action + optional cart trigger */}
        <div className="flex items-center gap-4 shrink-0">
          {cartCount > 0 && (
            <button
              onClick={onOpenCart}
              aria-label="Abrir pedido"
              className="relative p-2.5 rounded-lg bg-surface hover:bg-surface-hover text-foreground border border-surface-border transition-colors flex items-center gap-2 text-xs font-medium cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4 text-primary" />
              <span className="font-mono tabular-nums">{cartCount}</span>
            </button>
          )}

          <a
            href="#contato"
            className="hidden sm:inline-flex px-5 py-2.5 text-xs uppercase tracking-wider font-semibold text-white bg-primary hover:bg-primary-hover rounded-md transition-all duration-200 shadow-sm whitespace-nowrap shrink-0 items-center justify-center cursor-pointer"
          >
            Entrar em contato
          </a>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-muted hover:text-foreground focus:outline-none"
            aria-label="Alternar menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile navigation sheet */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-surface-border bg-secondary/95 px-6 py-6 space-y-4">
          <a
            href="#cardapio"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-base font-medium text-muted hover:text-foreground transition-colors"
          >
            Cardápio
          </a>
          <a
            href="#tradicao"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-base font-medium text-muted hover:text-foreground transition-colors"
          >
            Nossa Tradição
          </a>
          <a
            href="#localizacao"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-base font-medium text-muted hover:text-foreground transition-colors"
          >
            Localização
          </a>
          <a
            href="#contato"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-base font-medium text-muted hover:text-foreground transition-colors"
          >
            Contato
          </a>
          <div className="pt-2">
            <a
              href="#contato"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full inline-flex justify-center px-4 py-3 text-xs uppercase tracking-wider font-semibold text-white bg-primary hover:bg-primary-hover rounded-md transition-colors"
            >
              Entrar em contato
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
