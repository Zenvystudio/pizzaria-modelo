import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Copy, Check, ExternalLink } from 'lucide-react';
import { PizzeriaSettings } from '../types';

interface LocationSectionProps {
  settings?: PizzeriaSettings;
}

export const LocationSection: React.FC<LocationSectionProps> = ({ settings }) => {
  const [copied, setCopied] = useState(false);
  const address = settings?.address || 'Rua xxxxxxxxxxxxxx';

  const handleCopy = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <section id="localizacao" className="py-28 px-6 bg-surface/30 border-t border-surface-border">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="text-center max-w-xl mx-auto space-y-3">
          <div className="text-xs uppercase tracking-[0.25em] text-primary font-bold">
            Localização
          </div>
          <h2
            className="font-display font-bold text-foreground text-balance tracking-tight"
            style={{ fontSize: 'clamp(2.25rem, 4vw, 3.25rem)' }}
          >
            Onde Estamos
          </h2>
          <p className="text-muted text-sm leading-relaxed">
            Venha desfrutar de uma experiência intimista em nosso salão gastronômico.
          </p>
        </div>

        {/* Location Content Box */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto rounded-2xl bg-surface border border-surface-border p-8 md:p-12 space-y-8 shadow-xl"
        >
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-surface-border">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-mono uppercase text-muted tracking-wider">
                <MapPin className="w-4 h-4 text-primary" />
                <span>Endereço Oficial</span>
              </div>
              <div className="font-display text-2xl md:text-3xl font-bold text-foreground">
                {address}
              </div>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto">
              <button
                onClick={handleCopy}
                className="flex-1 md:flex-initial inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-surface-hover hover:bg-secondary text-foreground text-xs uppercase tracking-wider font-semibold border border-surface-border transition-colors cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-primary" />
                    <span>Copiado</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar</span>
                  </>
                )}
              </button>

              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(address)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 md:flex-initial inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer"
              >
                <span>Ver no Mapa</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Minimalist Stylized Map Card */}
          <div className="relative h-48 md:h-64 rounded-xl overflow-hidden bg-secondary border border-surface-border flex items-center justify-center">
            {/* Grid graphic background */}
            <div
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage:
                  'radial-gradient(circle at 1px 1px, #E31837 1px, transparent 0)',
                backgroundSize: '24px 24px',
              }}
              aria-hidden="true"
            />
            <div className="relative text-center space-y-3 p-6 z-10">
              <div className="w-12 h-12 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center mx-auto text-primary">
                <MapPin className="w-6 h-6" />
              </div>
              <div className="font-display text-lg font-bold text-foreground">
                {settings?.pizzeriaName || 'Pizzaria'}
              </div>
              <div className="text-xs text-muted font-mono">{address}</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
