import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Plus, Check, ShoppingBag, Sparkles, AlertCircle, EyeOff } from 'lucide-react';
import { MenuItem, CategoryItem } from '../types';

interface MenuSectionProps {
  products: MenuItem[];
  categories: CategoryItem[];
  isStoreOpen: boolean;
  closedMessage?: string;
  onAddToCart: (item: MenuItem) => void;
  cartItemIds: Set<string>;
}

export const MenuSection: React.FC<MenuSectionProps> = ({
  products,
  categories,
  isStoreOpen,
  closedMessage,
  onAddToCart,
  cartItemIds,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');

  // Filter active categories
  const activeCategories = categories.filter((c) => c.isActive !== false);

  const filteredItems = selectedCategory === 'todos'
    ? products
    : products.filter((item) => item.category === selectedCategory);

  const featuredItems = filteredItems.filter((item) => item.image);
  const textItems = filteredItems.filter((item) => !item.image);

  return (
    <section id="cardapio" className="py-28 px-6 bg-surface/30 border-t border-surface-border">
      <div className="max-w-7xl mx-auto space-y-16">
        {/* Closed Store Banner if not open */}
        {!isStoreOpen && (
          <div className="max-w-3xl mx-auto p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 flex items-center gap-3 text-xs">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <div>
              <span className="font-bold">Aviso do Estabelecimento:</span>{' '}
              {closedMessage || 'No momento não estamos aceitando novos pedidos. Consulte nosso cardápio!'}
            </div>
          </div>
        )}

        {/* Section Header: Centered & Minimal */}
        <div className="text-center max-w-2xl mx-auto space-y-4">
          <div className="flex items-center justify-center gap-2 text-xs uppercase tracking-[0.25em] text-primary font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Cardápio Digital</span>
          </div>
          <h2
            className="font-display font-bold text-foreground text-balance tracking-tight"
            style={{ fontSize: 'clamp(2.25rem, 4.5vw, 3.5rem)' }}
          >
            Nossas Receitas
          </h2>
          <p className="text-muted text-base leading-relaxed">
            Ingredientes de denominação de origem protegida, fermentação de 48 horas e queijos selecionados.
          </p>
        </div>

        {/* Interactive Filter Control: Clean Segmented Bar */}
        <div className="flex justify-center">
          <div className="inline-flex p-1.5 bg-surface border border-surface-border rounded-xl flex-wrap gap-1">
            <button
              onClick={() => setSelectedCategory('todos')}
              className={`px-5 py-2 text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer whitespace-nowrap ${
                selectedCategory === 'todos'
                  ? 'bg-primary text-white shadow-sm'
                  : 'text-muted hover:text-foreground'
              }`}
            >
              Todas
            </button>
            {activeCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-5 py-2 text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer whitespace-nowrap ${
                  selectedCategory === cat.id
                    ? 'bg-primary text-white shadow-sm'
                    : 'text-muted hover:text-foreground'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Marquee Featured Visual Items */}
        {featuredItems.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {featuredItems.map((item) => {
              const inCart = cartItemIds.has(item.id);
              const isAvailable = item.isAvailable !== false;

              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                  className={`group relative rounded-2xl overflow-hidden bg-surface border flex flex-col justify-between transition-all duration-300 shadow-lg ${
                    isAvailable
                      ? 'border-surface-border hover:border-primary/40'
                      : 'border-surface-border opacity-70'
                  }`}
                >
                  <div className="relative h-72 sm:h-80 w-full overflow-hidden bg-secondary">
                    <img
                      src={item.image}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      loading="lazy"
                      className={`w-full h-full object-cover object-center transition-transform duration-700 ${
                        isAvailable ? 'group-hover:scale-105' : 'grayscale-[40%]'
                      }`}
                    />
                    <div
                      className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent pointer-events-none"
                      aria-hidden="true"
                    />

                    {/* Price Badge */}
                    <div className="absolute top-4 right-4 backdrop-blur-md bg-secondary/85 px-3.5 py-1.5 rounded-lg border border-surface-border text-foreground font-mono font-bold text-sm tabular-nums">
                      R$ {item.price.toFixed(2).replace('.', ',')}
                    </div>

                    {/* Unavailable Badge */}
                    {!isAvailable && (
                      <div className="absolute top-4 left-4 backdrop-blur-md bg-red-950/85 text-red-300 px-3 py-1.5 rounded-lg border border-red-800 text-xs font-semibold flex items-center gap-1.5">
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>Esgotado / Indisponível</span>
                      </div>
                    )}
                  </div>

                  <div className="p-7 space-y-4">
                    <div>
                      <h3 className="font-display text-2xl font-bold text-foreground">
                        {item.name}
                      </h3>
                      <div className="text-xs text-muted/80 mt-1 uppercase tracking-wider font-mono">
                        {activeCategories.find((c) => c.id === item.category)?.name || 'Forno a Lenha'}
                      </div>
                    </div>

                    <p className="text-muted text-sm leading-relaxed">
                      {item.description}
                    </p>

                    <div className="pt-2 flex items-center justify-between border-t border-surface-border">
                      <span className="text-xs text-muted font-medium">35cm · 8 fatias</span>
                      {isAvailable ? (
                        <button
                          onClick={() => onAddToCart(item)}
                          disabled={!isStoreOpen}
                          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all duration-200 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                            inCart
                              ? 'bg-surface-hover text-foreground border border-surface-border'
                              : 'bg-primary text-white hover:bg-primary-hover shadow-sm'
                          }`}
                        >
                          {inCart ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-primary" />
                              <span>No Pedido</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-3.5 h-3.5" />
                              <span>Adicionar</span>
                            </>
                          )}
                        </button>
                      ) : (
                        <span className="text-xs text-muted font-mono uppercase">
                          Item Indisponível
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Editorial List for Remaining Menu Items */}
        {textItems.length > 0 && (
          <div className="space-y-4 pt-4">
            <div className="text-xs font-mono uppercase tracking-widest text-muted pb-2 border-b border-surface-border">
              Outras Seleções do Cardápio
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {textItems.map((item) => {
                const inCart = cartItemIds.has(item.id);
                const isAvailable = item.isAvailable !== false;

                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4 }}
                    className={`p-6 rounded-xl bg-surface border transition-colors flex flex-col justify-between space-y-4 ${
                      isAvailable ? 'border-surface-border hover:border-surface-hover' : 'border-surface-border opacity-70'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-display text-xl font-bold text-foreground">
                            {item.name}
                          </h4>
                          {!isAvailable && (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20 font-mono uppercase">
                              Indisponível
                            </span>
                          )}
                        </div>
                        <p className="text-muted text-xs leading-relaxed max-w-md">
                          {item.description}
                        </p>
                      </div>
                      <div className="font-mono text-base font-bold text-foreground shrink-0 tabular-nums">
                        R$ {item.price.toFixed(2).replace('.', ',')}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-surface-border/60">
                      <span className="text-[11px] text-muted font-mono uppercase tracking-wider">
                        {activeCategories.find((c) => c.id === item.category)?.name || 'Forno a Lenha'}
                      </span>
                      {isAvailable ? (
                        <button
                          onClick={() => onAddToCart(item)}
                          disabled={!isStoreOpen}
                          className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                            inCart
                              ? 'bg-surface-hover text-foreground'
                              : 'bg-primary/10 text-primary hover:bg-primary hover:text-white'
                          }`}
                        >
                          {inCart ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>Adicionado</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-3 h-3" />
                              <span>Adicionar</span>
                            </>
                          )}
                        </button>
                      ) : (
                        <span className="text-xs text-muted/60 font-mono">
                          Indisponível hoje
                        </span>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
