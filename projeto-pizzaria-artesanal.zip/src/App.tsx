/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { AboutSection } from './components/AboutSection';
import { LocationSection } from './components/LocationSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { AdminLayout } from './admin/AdminLayout';
import { AdminLogin } from './admin/AdminLogin';
import { MenuItem, CategoryItem, CartItem, Order, PizzeriaSettings, AdminUser } from './types';
import { ShoppingBag, ArrowRight } from 'lucide-react';
import { subscribeToProducts } from './services/productService';
import { subscribeToCategories } from './services/categoryService';
import { subscribeToSettings } from './services/settingsService';
import { subscribeToOrders } from './services/orderService';
import { subscribeToAuth, checkAdminSession } from './services/authService';
import { bootstrapDatabaseIfEmpty, DEFAULT_SETTINGS, DEFAULT_CATEGORIES } from './services/bootstrapService';
import { MENU_ITEMS } from './data/menu';

export default function App() {
  const [isAdminRoute, setIsAdminRoute] = useState(
    window.location.pathname === '/admin' || window.location.hash === '#admin'
  );

  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Real-time data from Firestore
  const [products, setProducts] = useState<MenuItem[]>(
    MENU_ITEMS.map((item) => ({ ...item, isAvailable: true }))
  );
  const [categories, setCategories] = useState<CategoryItem[]>(DEFAULT_CATEGORIES);
  const [settings, setSettings] = useState<PizzeriaSettings>(DEFAULT_SETTINGS);
  const [orders, setOrders] = useState<Order[]>([]);

  // Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Sync URL routing
  useEffect(() => {
    const handleLocationChange = () => {
      const isAdmin = window.location.pathname === '/admin' || window.location.hash === '#admin';
      setIsAdminRoute(isAdmin);
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const navigateToAdmin = () => {
    window.history.pushState({}, '', '/admin');
    setIsAdminRoute(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToPublic = () => {
    window.history.pushState({}, '', '/');
    if (window.location.hash === '#admin') {
      window.location.hash = '';
    }
    setIsAdminRoute(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Auth Listener
  useEffect(() => {
    const unsubAuth = subscribeToAuth((user) => {
      setAdminUser(user);
      setAuthLoading(false);
    });
    return () => unsubAuth();
  }, []);

  // Real-time Firestore Subscriptions
  useEffect(() => {
    bootstrapDatabaseIfEmpty();

    const unsubProducts = subscribeToProducts((newProducts) => {
      setProducts(newProducts);
    });

    const unsubCategories = subscribeToCategories((newCategories) => {
      setCategories(newCategories);
    });

    const unsubSettings = subscribeToSettings((newSettings) => {
      setSettings(newSettings);
    });

    return () => {
      unsubProducts();
      unsubCategories();
      unsubSettings();
    };
  }, []);

  // Orders listener for the operational panel
  useEffect(() => {
    const unsubOrders = subscribeToOrders((newOrders) => {
      setOrders(newOrders);
    });

    return () => {
      unsubOrders();
    };
  }, []);

  const handleAddToCart = (item: MenuItem) => {
    if (item.isAvailable === false || !settings.isOpen) {
      return;
    }

    setCart((prev) => {
      const existing = prev.find((ci) => ci.item.id === item.id);
      if (existing) {
        return prev.map((ci) =>
          ci.item.id === item.id ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [...prev, { item, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((ci) => {
          if (ci.item.id === id) {
            const newQty = ci.quantity + delta;
            return newQty > 0 ? { ...ci, quantity: newQty } : null;
          }
          return ci;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const cartTotalItems = cart.reduce((sum, ci) => sum + ci.quantity, 0);
  const cartTotalPrice = cart.reduce((sum, ci) => sum + ci.item.price * ci.quantity, 0);
  const cartItemIds = new Set(cart.map((ci) => ci.item.id));

  // If on /admin route:
  if (isAdminRoute) {
    if (authLoading) {
      return (
        <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-6">
          <div className="text-center space-y-3">
            <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
            <div className="text-xs font-mono text-muted uppercase tracking-wider">
              Verificando credenciais...
            </div>
          </div>
        </div>
      );
    }

    // 1. Not authenticated as admin -> Show exclusive employee login form
    if (!adminUser) {
      return (
        <AdminLogin
          onBackToSite={navigateToPublic}
          onLoginSuccess={() => {
            checkAdminSession();
          }}
        />
      );
    }

    // 2. Fully Authenticated Staff -> Show Operational Admin Dashboard
    return (
      <AdminLayout
        adminUser={adminUser}
        orders={orders}
        products={products}
        categories={categories}
        settings={settings}
        onExitAdmin={navigateToPublic}
      />
    );
  }

  // Public Pizzeria Customer Landing Page
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col selection:bg-primary selection:text-white">
      {/* Navigation */}
      <Navbar
        cartCount={cartTotalItems}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Main Sections */}
      <main className="flex-1">
        <Hero />
        <MenuSection
          products={products}
          categories={categories}
          isStoreOpen={settings.isOpen}
          closedMessage={settings.closedMessage}
          onAddToCart={handleAddToCart}
          cartItemIds={cartItemIds}
        />
        <AboutSection />
        <LocationSection settings={settings} />
        <ContactSection settings={settings} />
      </main>

      {/* Footer with employee portal link */}
      <Footer onOpenAdmin={navigateToAdmin} />

      {/* Floating Bottom Quick Cart Bar when items are selected */}
      {cartTotalItems > 0 && !isCartOpen && (
        <aside
          aria-label="Resumo do pedido"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 w-[92%] max-w-lg shadow-2xl animate-fade-in"
        >
          <div className="bg-secondary/95 backdrop-blur-md border border-primary/40 rounded-xl p-3.5 sm:px-5 flex items-center justify-between gap-4 text-foreground">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-primary text-white flex items-center justify-center font-bold text-xs shrink-0">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-foreground">
                  {cartTotalItems} {cartTotalItems === 1 ? 'item selecionado' : 'itens selecionados'}
                </div>
                <div className="font-mono text-xs text-muted tabular-nums">
                  Total: R$ {cartTotalPrice.toFixed(2).replace('.', ',')}
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsCartOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-wider font-semibold transition-colors shrink-0 cursor-pointer"
            >
              <span>Ver Pedido</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </aside>
      )}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onClearCart={handleClearCart}
        settings={settings}
      />
    </div>
  );
}
