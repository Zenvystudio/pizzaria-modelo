import React, { useState } from 'react';
import {
  LayoutDashboard,
  ShoppingBag,
  Pizza,
  FolderTree,
  Settings,
  LogOut,
  ExternalLink,
  Flame,
  Menu as MenuIcon,
  X,
  Users,
  ShieldCheck,
} from 'lucide-react';
import { Order, MenuItem, CategoryItem, PizzeriaSettings, AdminUser } from '../types';
import { DashboardTab } from './tabs/DashboardTab';
import { OrdersTab } from './tabs/OrdersTab';
import { ProductsTab } from './tabs/ProductsTab';
import { CategoriesTab } from './tabs/CategoriesTab';
import { SettingsTab } from './tabs/SettingsTab';
import { SecurityTab } from './tabs/SecurityTab';
import { StaffTab } from './tabs/StaffTab';
import { logout } from '../services/authService';
import { updatePizzeriaSettings } from '../services/settingsService';

type AdminTab = 'dashboard' | 'pedidos' | 'produtos' | 'categorias' | 'configuracoes' | 'seguranca' | 'equipe';

interface AdminLayoutProps {
  adminUser: AdminUser;
  orders: Order[];
  products: MenuItem[];
  categories: CategoryItem[];
  settings: PizzeriaSettings;
  onExitAdmin: () => void;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  adminUser,
  orders,
  products,
  categories,
  settings,
  onExitAdmin,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const newOrdersCount = orders.filter((o) => o.status === 'novo').length;

  const handleQuickToggleStore = async () => {
    try {
      await updatePizzeriaSettings({ isOpen: !settings.isOpen });
    } catch (err) {
      console.error(err);
      alert('Erro ao alterar status da pizzaria.');
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      onExitAdmin();
    } catch (err) {
      console.error(err);
    }
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'pedidos', label: 'Pedidos', icon: ShoppingBag, badge: newOrdersCount },
    { id: 'produtos', label: 'Cardápio & Produtos', icon: Pizza },
    { id: 'categorias', label: 'Categorias', icon: FolderTree },
    { id: 'configuracoes', label: 'Configurações', icon: Settings },
    { id: 'seguranca', label: 'Segurança', icon: ShieldCheck },
    { id: 'equipe', label: 'Equipe & Acessos', icon: Users },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Top Header */}
      <header className="sticky top-0 z-40 w-full bg-secondary/95 backdrop-blur-md border-b border-surface-border px-6 h-18 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
            className="md:hidden p-2 text-muted hover:text-foreground cursor-pointer"
            aria-label="Abrir menu lateral"
          >
            {mobileSidebarOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-3">
            <span className="font-display text-2xl font-bold tracking-tight text-foreground">
              {settings.pizzeriaName}
            </span>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-primary/20 text-primary border border-primary/30 uppercase font-semibold">
              Painel Operacional
            </span>
          </div>
        </div>

        {/* Right Header items */}
        <div className="flex items-center gap-3 md:gap-5">
          {/* Open/Closed quick toggle */}
          <button
            onClick={handleQuickToggleStore}
            className={`hidden sm:inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold border transition-colors cursor-pointer ${
              settings.isOpen
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                : 'bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20'
            }`}
            title="Alternar se a pizzaria está aberta para receber pedidos"
          >
            <span className={`w-2 h-2 rounded-full ${settings.isOpen ? 'bg-emerald-400' : 'bg-red-500'}`} />
            <span>{settings.isOpen ? 'Forno Aberto' : 'Forno Fechado'}</span>
          </button>

          {/* View Public Site button */}
          <button
            onClick={onExitAdmin}
            className="inline-flex items-center gap-1.5 text-xs text-muted hover:text-foreground font-semibold px-3 py-1.5 rounded-lg border border-surface-border hover:bg-surface transition-colors cursor-pointer"
          >
            <span>Ver Site Público</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>

          {/* User info and Logout */}
          <div className="flex items-center gap-2 pl-2 border-l border-surface-border">
            <div className="hidden lg:block text-right">
              <div className="text-xs font-semibold text-foreground max-w-[160px] truncate">
                {adminUser.name || 'Administrador'}
              </div>
              <div className="text-[10px] font-mono text-muted uppercase">
                {adminUser.role === 'admin' ? 'Administração' : 'Equipe'}
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="p-2 text-muted hover:text-primary transition-colors rounded-lg cursor-pointer"
              title="Sair da Conta"
              aria-label="Sair da conta"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Desktop */}
        <aside className="hidden md:flex w-64 flex-col justify-between bg-secondary/60 border-r border-surface-border p-5 space-y-6 shrink-0">
          <nav className="space-y-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as AdminTab)}
                  className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-primary text-white shadow-md shadow-primary/20'
                      : 'text-muted hover:text-foreground hover:bg-surface'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {Boolean(item.badge && item.badge > 0) && (
                    <span
                      className={`font-mono text-[11px] px-2 py-0.5 rounded-full font-bold ${
                        isActive ? 'bg-white text-primary' : 'bg-primary text-white'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          <div className="p-4 rounded-xl bg-surface border border-surface-border space-y-2 text-xs">
            <div className="flex items-center gap-2 text-primary font-semibold">
              <Flame className="w-4 h-4" />
              <span>Forno Sincronizado</span>
            </div>
            <p className="text-[11px] text-muted leading-relaxed">
              Alterações em preços, disponibilidade e status de pedidos são refletidas em tempo real para os clientes.
            </p>
          </div>
        </aside>

        {/* Mobile Sidebar overlay */}
        {mobileSidebarOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            <div
              className="fixed inset-0 bg-black/70 backdrop-blur-sm"
              onClick={() => setMobileSidebarOpen(false)}
            />
            <div className="relative w-64 max-w-[80%] bg-secondary border-r border-surface-border p-5 flex flex-col justify-between h-full z-10">
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-surface-border">
                  <span className="font-display font-bold text-lg text-foreground">Menu Operacional</span>
                  <button onClick={() => setMobileSidebarOpen(false)} className="p-1 text-muted">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <nav className="space-y-1.5">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id as AdminTab);
                          setMobileSidebarOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-semibold cursor-pointer ${
                          isActive ? 'bg-primary text-white' : 'text-muted hover:text-foreground'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Icon className="w-4 h-4" />
                          <span>{item.label}</span>
                        </div>
                        {Boolean(item.badge && item.badge > 0) && (
                          <span className="font-mono text-[11px] px-2 py-0.5 rounded-full bg-primary text-white font-bold">
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </nav>
              </div>

              <button
                onClick={handleLogout}
                className="w-full py-3 rounded-lg bg-surface border border-surface-border text-xs text-red-400 font-semibold flex items-center justify-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Sair da Conta</span>
              </button>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 lg:p-10">
          <div className="max-w-6xl mx-auto">
            {activeTab === 'dashboard' && (
              <DashboardTab
                orders={orders}
                onNavigateTab={(tab) => setActiveTab(tab)}
                onOpenOrderDetails={(order) => {
                  setSelectedOrder(order);
                  setActiveTab('pedidos');
                }}
                onQuickToggleStore={handleQuickToggleStore}
                isOpen={settings.isOpen}
              />
            )}

            {activeTab === 'pedidos' && (
              <OrdersTab
                orders={orders}
                selectedOrder={selectedOrder}
                onSelectOrder={(order) => setSelectedOrder(order)}
              />
            )}

            {activeTab === 'produtos' && (
              <ProductsTab products={products} categories={categories} />
            )}

            {activeTab === 'categorias' && (
              <CategoriesTab categories={categories} />
            )}

            {activeTab === 'configuracoes' && (
              <SettingsTab settings={settings} />
            )}

            {activeTab === 'seguranca' && (
              <SecurityTab />
            )}

            {activeTab === 'equipe' && (
              <StaffTab currentAdmin={adminUser} />
            )}
          </div>
        </main>
      </div>
    </div>
  );
};
