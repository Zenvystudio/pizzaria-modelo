import React from 'react';
import {
  ShoppingBag,
  Clock,
  Bike,
  CheckCircle2,
  DollarSign,
  TrendingUp,
  ArrowRight,
  Flame,
  PlusCircle,
  Store,
} from 'lucide-react';
import { Order, OrderStatus } from '../../types';

interface DashboardTabProps {
  orders: Order[];
  onNavigateTab: (tab: 'dashboard' | 'pedidos' | 'produtos' | 'categorias' | 'configuracoes') => void;
  onOpenOrderDetails: (order: Order) => void;
  onQuickToggleStore: () => void;
  isOpen: boolean;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  orders,
  onNavigateTab,
  onOpenOrderDetails,
  onQuickToggleStore,
  isOpen,
}) => {
  // Compute counts
  const newOrders = orders.filter((o) => o.status === 'novo');
  const preparingOrders = orders.filter((o) => o.status === 'em_preparacao' || o.status === 'confirmado');
  const deliveringOrders = orders.filter((o) => o.status === 'saiu_para_entrega' || o.status === 'pronto');
  const completedOrders = orders.filter((o) => o.status === 'concluido');

  // Compute today's revenue (from completed or confirmed orders created today)
  const todayStr = new Date().toISOString().slice(0, 10);
  const todaysRevenue = orders
    .filter((o) => o.status !== 'cancelado' && (o.createdAt?.startsWith(todayStr) || true))
    .reduce((sum, o) => sum + o.total, 0);

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'novo':
        return <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-primary/20 text-primary border border-primary/30 font-bold uppercase">Novo</span>;
      case 'confirmado':
        return <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-blue-500/20 text-blue-400 border border-blue-500/30 uppercase">Confirmado</span>;
      case 'em_preparacao':
        return <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-amber-500/20 text-amber-400 border border-amber-500/30 uppercase">No Forno</span>;
      case 'pronto':
        return <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">Pronto</span>;
      case 'saiu_para_entrega':
        return <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-purple-500/20 text-purple-400 border border-purple-500/30 uppercase">Em Entrega</span>;
      case 'concluido':
        return <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-neutral-800 text-neutral-300 border border-neutral-700 uppercase">Concluído</span>;
      case 'cancelado':
        return <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-red-900/30 text-red-400 border border-red-800/40 uppercase">Cancelado</span>;
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner & Quick Status */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-2xl bg-surface border border-surface-border">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="font-display text-2xl font-bold text-foreground">
              Visão Operacional do Forno
            </h2>
            <span className={`w-2.5 h-2.5 rounded-full ${isOpen ? 'bg-emerald-400' : 'bg-red-500'}`} />
          </div>
          <p className="text-xs text-muted">
            {isOpen ? 'A pizzaria está aberta e recebendo pedidos normalmente.' : 'A pizzaria está fechada para novos pedidos no momento.'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onQuickToggleStore}
            className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer border ${
              isOpen
                ? 'bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20'
                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
            }`}
          >
            {isOpen ? 'Pausar Atendimento' : 'Abrir Pizzaria'}
          </button>

          <button
            onClick={() => onNavigateTab('pedidos')}
            className="px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider bg-primary hover:bg-primary-hover text-white transition-colors cursor-pointer shadow-sm"
          >
            Ver Pedidos
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Novos */}
        <div
          onClick={() => onNavigateTab('pedidos')}
          className={`p-5 rounded-xl border transition-all cursor-pointer ${
            newOrders.length > 0
              ? 'bg-primary/10 border-primary/50 shadow-lg shadow-primary/10'
              : 'bg-surface border-surface-border hover:border-surface-hover'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted font-medium">Novos Pedidos</span>
            <div className={`p-2 rounded-lg ${newOrders.length > 0 ? 'bg-primary text-white' : 'bg-secondary text-muted'}`}>
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 font-mono text-3xl font-bold text-foreground tabular-nums">
            {newOrders.length}
          </div>
          <div className="text-[11px] text-muted mt-1">Aguardando aceite</div>
        </div>

        {/* Em Preparação */}
        <div
          onClick={() => onNavigateTab('pedidos')}
          className="p-5 rounded-xl bg-surface border border-surface-border hover:border-surface-hover transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted font-medium">No Forno / Preparo</span>
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <Flame className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 font-mono text-3xl font-bold text-foreground tabular-nums">
            {preparingOrders.length}
          </div>
          <div className="text-[11px] text-muted mt-1">Na massa e forno</div>
        </div>

        {/* Em Entrega */}
        <div
          onClick={() => onNavigateTab('pedidos')}
          className="p-5 rounded-xl bg-surface border border-surface-border hover:border-surface-hover transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted font-medium">Em Trânsito / Pronto</span>
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
              <Bike className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 font-mono text-3xl font-bold text-foreground tabular-nums">
            {deliveringOrders.length}
          </div>
          <div className="text-[11px] text-muted mt-1">Entregas em rota</div>
        </div>

        {/* Concluídos */}
        <div
          onClick={() => onNavigateTab('pedidos')}
          className="p-5 rounded-xl bg-surface border border-surface-border hover:border-surface-hover transition-colors cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted font-medium">Concluídos</span>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 font-mono text-3xl font-bold text-foreground tabular-nums">
            {completedOrders.length}
          </div>
          <div className="text-[11px] text-muted mt-1">Finalizados hoje</div>
        </div>

        {/* Faturamento do Dia */}
        <div className="p-5 rounded-xl bg-surface border border-surface-border">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted font-medium">Faturamento Estimado</span>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 font-mono text-2xl font-bold text-emerald-400 tabular-nums">
            R$ {todaysRevenue.toFixed(2).replace('.', ',')}
          </div>
          <div className="text-[11px] text-muted mt-1">Pedidos registrados</div>
        </div>
      </div>

      {/* Quick Action Shortcuts */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <button
          onClick={() => onNavigateTab('produtos')}
          className="p-4 rounded-xl bg-surface border border-surface-border hover:border-surface-hover hover:bg-secondary transition-all text-left flex items-center justify-between cursor-pointer"
        >
          <div className="space-y-1">
            <div className="text-xs font-semibold text-foreground">Gerenciar Cardápio</div>
            <div className="text-[11px] text-muted">Editar itens e preços</div>
          </div>
          <PlusCircle className="w-4 h-4 text-primary shrink-0" />
        </button>

        <button
          onClick={() => onNavigateTab('categorias')}
          className="p-4 rounded-xl bg-surface border border-surface-border hover:border-surface-hover hover:bg-secondary transition-all text-left flex items-center justify-between cursor-pointer"
        >
          <div className="space-y-1">
            <div className="text-xs font-semibold text-foreground">Categorias</div>
            <div className="text-[11px] text-muted">Organizar seções</div>
          </div>
          <ArrowRight className="w-4 h-4 text-muted shrink-0" />
        </button>

        <button
          onClick={() => onNavigateTab('configuracoes')}
          className="p-4 rounded-xl bg-surface border border-surface-border hover:border-surface-hover hover:bg-secondary transition-all text-left flex items-center justify-between cursor-pointer"
        >
          <div className="space-y-1">
            <div className="text-xs font-semibold text-foreground">Taxas e Horários</div>
            <div className="text-[11px] text-muted">Ajustar parâmetros</div>
          </div>
          <Store className="w-4 h-4 text-muted shrink-0" />
        </button>

        <button
          onClick={() => onNavigateTab('pedidos')}
          className="p-4 rounded-xl bg-surface border border-surface-border hover:border-surface-hover hover:bg-secondary transition-all text-left flex items-center justify-between cursor-pointer"
        >
          <div className="space-y-1">
            <div className="text-xs font-semibold text-foreground">Fila de Pedidos</div>
            <div className="text-[11px] text-muted">Visualização completa</div>
          </div>
          <TrendingUp className="w-4 h-4 text-muted shrink-0" />
        </button>
      </div>

      {/* Recent Orders Table */}
      <div className="rounded-2xl bg-surface border border-surface-border overflow-hidden shadow-lg">
        <div className="p-6 border-b border-surface-border flex items-center justify-between">
          <div>
            <h3 className="font-display text-xl font-bold text-foreground">
              Pedidos Recentes
            </h3>
            <p className="text-xs text-muted">Últimas solicitações recebidas em tempo real</p>
          </div>
          <button
            onClick={() => onNavigateTab('pedidos')}
            className="text-xs font-semibold text-primary hover:text-primary-hover transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span>Ver todos</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {orders.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <ShoppingBag className="w-10 h-10 text-muted mx-auto stroke-1" />
            <div className="text-sm text-muted">Nenhum pedido registrado até o momento.</div>
            <div className="text-xs text-muted/60">
              Quando clientes realizarem pedidos pelo cardápio, eles aparecerão aqui instantaneamente.
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-secondary/60 text-muted uppercase tracking-wider font-mono border-b border-surface-border">
                <tr>
                  <th className="py-3 px-6">Pedido</th>
                  <th className="py-3 px-6">Cliente</th>
                  <th className="py-3 px-6">Modalidade</th>
                  <th className="py-3 px-6">Itens</th>
                  <th className="py-3 px-6">Total</th>
                  <th className="py-3 px-6">Status</th>
                  <th className="py-3 px-6 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-border">
                {orders.slice(0, 6).map((order) => (
                  <tr key={order.id} className="hover:bg-secondary/40 transition-colors">
                    <td className="py-4 px-6 font-mono font-bold text-foreground">
                      #{order.id}
                    </td>
                    <td className="py-4 px-6">
                      <div className="font-medium text-foreground">{order.customerName}</div>
                      <div className="text-[11px] text-muted font-mono">{order.customerPhone}</div>
                    </td>
                    <td className="py-4 px-6 capitalize text-muted">
                      {order.orderType}
                    </td>
                    <td className="py-4 px-6 text-muted">
                      {order.items.map((i) => `${i.quantity}x ${i.name}`).join(', ')}
                    </td>
                    <td className="py-4 px-6 font-mono font-bold text-foreground tabular-nums">
                      R$ {order.total.toFixed(2).replace('.', ',')}
                    </td>
                    <td className="py-4 px-6">
                      {getStatusBadge(order.status)}
                    </td>
                    <td className="py-4 px-6 text-right">
                      <button
                        onClick={() => onOpenOrderDetails(order)}
                        className="px-3 py-1.5 rounded-md bg-surface-hover hover:bg-secondary text-foreground font-medium text-xs border border-surface-border transition-colors cursor-pointer"
                      >
                        Detalhes
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
