import React, { useState, useEffect } from 'react';
import { UserPlus, Shield, ShieldAlert, Trash2, Check, UserCheck, AlertCircle, Key, Users } from 'lucide-react';
import { AuthorizedStaff, AdminUser } from '../../types';
import {
  subscribeToAuthorizedStaff,
  authorizeNewStaff,
  revokeStaffAccess,
  getActiveAdmins,
} from '../../services/staffService';

interface StaffTabProps {
  currentAdmin: AdminUser;
}

export const StaffTab: React.FC<StaffTabProps> = ({ currentAdmin }) => {
  const [staffList, setStaffList] = useState<AuthorizedStaff[]>([]);
  const [activeAdmins, setActiveAdmins] = useState<AdminUser[]>([]);
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<'admin' | 'staff'>('staff');
  const [loading, setLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsub = subscribeToAuthorizedStaff((list) => {
      setStaffList(list);
    });

    getActiveAdmins().then(setActiveAdmins);

    return () => unsub();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleAuthorize = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const emailTrim = newEmail.trim().toLowerCase();
    if (!emailTrim || !emailTrim.includes('@')) {
      setError('Informe um e-mail válido.');
      return;
    }

    setLoading(true);
    try {
      await authorizeNewStaff({
        email: emailTrim,
        name: newName.trim(),
        role: newRole,
      });

      showToast(`Funcionário ${emailTrim} autorizado com sucesso!`);
      setNewEmail('');
      setNewName('');
      setNewRole('staff');
      getActiveAdmins().then(setActiveAdmins);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Erro ao autorizar funcionário no banco de dados.');
    } finally {
      setLoading(false);
    }
  };

  const handleRevoke = async (email: string) => {
    if (confirm(`Deseja revogar o acesso administrativo de "${email}" imediatamente?`)) {
      try {
        await revokeStaffAccess(email);
        showToast(`Acesso de ${email} revogado.`);
        getActiveAdmins().then(setActiveAdmins);
      } catch (err: any) {
        console.error(err);
        alert(err.message || 'Erro ao revogar acesso.');
      }
    }
  };

  return (
    <div className="space-y-8 max-w-5xl">
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 p-4 rounded-xl bg-emerald-600 text-white text-xs font-semibold shadow-2xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="bg-surface p-6 rounded-2xl border border-surface-border space-y-2">
        <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-primary font-bold">
          <Shield className="w-4 h-4" />
          <span>Segurança & Controle de Acesso (ABAC)</span>
        </div>
        <h2 className="font-display text-2xl font-bold text-foreground">
          Gestão de Equipe & Funcionários
        </h2>
        <p className="text-xs text-muted leading-relaxed">
          Somente colaboradores expressamente pré-autorizados pelo proprietário conseguem visualizar o painel, gerenciar pedidos e editar o cardápio. Clientes comuns e visitantes têm o acesso bloqueado automaticamente pelo banco de dados.
        </p>
      </div>

      {/* Operational Security Banner */}
      <div className="p-5 rounded-2xl bg-secondary border border-surface-border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold text-foreground">Acesso Administrativo:</span>
            <span className="font-mono text-xs text-primary font-bold">Painel Operacional Ativo</span>
          </div>
          <p className="text-[11px] text-muted">
            Acesso protegido por autenticação e regras de segurança.
          </p>
        </div>

        <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold font-mono">
          Proteção Ativa
        </span>
      </div>

      {/* Authorize New Staff Form */}
      <div className="p-6 rounded-2xl bg-surface border border-surface-border space-y-6 shadow-xl">
        <div className="flex items-center gap-2">
          <UserPlus className="w-5 h-5 text-primary" />
          <h3 className="font-display text-xl font-bold text-foreground">
            Autorizar Novo Colaborador
          </h3>
        </div>

        {error && (
          <div className="p-3.5 rounded-lg bg-primary/10 border border-primary/30 flex items-start gap-2 text-xs text-primary">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleAuthorize} className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
          <div className="md:col-span-5 space-y-1.5">
            <label className="block text-xs font-medium text-foreground">
              E-mail do Funcionário *
            </label>
            <input
              type="email"
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              placeholder="funcionario@gmail.com"
              required
              className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs font-mono focus:outline-none focus:border-primary"
            />
          </div>

          <div className="md:col-span-4 space-y-1.5">
            <label className="block text-xs font-medium text-foreground">
              Nome ou Apelido
            </label>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Ex: Carlos (Pizzaiolo)"
              className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary"
            />
          </div>

          <div className="md:col-span-3 space-y-1.5">
            <label className="block text-xs font-medium text-foreground">
              Função
            </label>
            <select
              value={newRole}
              onChange={(e) => setNewRole(e.target.value as any)}
              className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs font-semibold focus:outline-none focus:border-primary"
            >
              <option value="staff">Equipe / Balcão</option>
              <option value="admin">Gerente / Administrador</option>
            </select>
          </div>

          <div className="md:col-span-12 flex justify-end pt-2">
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 rounded-lg bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-wider font-semibold transition-colors shadow-lg shadow-primary/20 cursor-pointer disabled:opacity-50 flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>{loading ? 'Salvando...' : 'Conceder Autorização'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Staff List Table */}
      <div className="rounded-2xl bg-surface border border-surface-border overflow-hidden shadow-xl space-y-0">
        <div className="p-6 border-b border-surface-border flex items-center justify-between">
          <div>
            <h3 className="font-display text-xl font-bold text-foreground">
              Colaboradores Autorizados
            </h3>
            <p className="text-xs text-muted">
              Lista de contas que possuem permissão confirmada no Cloud Firestore.
            </p>
          </div>

          <span className="text-xs font-mono text-muted">
            {staffList.length + 1} membros ativos
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-secondary/60 text-muted uppercase tracking-wider font-mono border-b border-surface-border">
              <tr>
                <th className="py-3.5 px-6">Colaborador</th>
                <th className="py-3.5 px-6">Permissão</th>
                <th className="py-3.5 px-6">Autorizado por</th>
                <th className="py-3.5 px-6">Data</th>
                <th className="py-3.5 px-6 text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">

              {/* Dedicated Administrator row */}
              <tr className="bg-primary/5">
                <td className="py-4 px-6">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-primary/20 text-primary flex items-center justify-center font-bold text-xs">
                      🔐
                    </div>
                    <div>
                      <div className="font-semibold text-foreground">Administrador Geral</div>
                      <div className="font-mono text-[11px] text-primary font-bold">pizzariateste123</div>
                    </div>
                  </div>
                </td>
                <td className="py-4 px-6">
                  <span className="font-mono px-2 py-0.5 rounded bg-primary/20 text-primary border border-primary/30 font-bold uppercase text-[10px]">
                    Administrador
                  </span>
                </td>
                <td className="py-4 px-6 font-mono text-muted text-[11px]">Backend Configurado</td>
                <td className="py-4 px-6 font-mono text-muted text-[11px]">Ativo</td>
                <td className="py-4 px-6 text-right text-muted font-mono text-[11px]">Protegido</td>
              </tr>

              {staffList.map((member) => (
                <tr key={member.email} className="hover:bg-secondary/30 transition-colors">
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-secondary text-muted flex items-center justify-center font-bold text-xs">
                        <Users className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">
                          {member.name || 'Funcionário'}
                        </div>
                        <div className="font-mono text-[11px] text-muted">{member.email}</div>
                      </div>
                    </div>
                  </td>

                  <td className="py-4 px-6">
                    <span
                      className={`font-mono px-2 py-0.5 rounded uppercase text-[10px] font-semibold border ${
                        member.role === 'admin'
                          ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                          : 'bg-secondary text-muted border-surface-border'
                      }`}
                    >
                      {member.role === 'admin' ? 'Gerente' : 'Operação'}
                    </span>
                  </td>

                  <td className="py-4 px-6 font-mono text-muted text-[11px]">
                    {member.addedBy || 'Administrador'}
                  </td>

                  <td className="py-4 px-6 font-mono text-muted text-[11px]">
                    {new Date(member.createdAt || '').toLocaleDateString()}
                  </td>

                  <td className="py-4 px-6 text-right">
                    <button
                      onClick={() => handleRevoke(member.email)}
                      className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-colors cursor-pointer"
                      title="Revogar Acesso"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
