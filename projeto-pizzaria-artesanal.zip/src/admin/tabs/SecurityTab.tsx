import React, { useState } from 'react';
import { Shield, KeyRound, Eye, EyeOff, CheckCircle2, AlertCircle, Lock, ShieldCheck, X } from 'lucide-react';
import { changePanelPassword } from '../../services/authService';

export const SecurityTab: React.FC = () => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [authPassword, setAuthPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [showAuthPass, setShowAuthPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleOpenForm = () => {
    setIsFormOpen(true);
    setError(null);
    setSuccessMessage(null);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setAuthPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (!authPassword.trim()) {
      setError('Por favor, informe a senha de autorização para alteração.');
      return;
    }

    if (!newPassword.trim()) {
      setError('Por favor, informe a nova senha de acesso ao painel.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('A nova senha e a confirmação não coincidem.');
      return;
    }

    if (newPassword.trim().length < 6) {
      setError('A nova senha deve ter no mínimo 6 caracteres.');
      return;
    }

    setLoading(true);
    try {
      const res = await changePanelPassword(authPassword, newPassword, confirmPassword);
      setSuccessMessage(res.message || 'Senha alterada com sucesso!');
      setAuthPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setIsFormOpen(false);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Erro ao alterar a senha do painel.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Tab Header */}
      <div className="bg-surface p-6 sm:p-8 rounded-2xl border border-surface-border space-y-3 shadow-xl">
        <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-primary font-bold">
          <Shield className="w-4 h-4" />
          <span>Configurações de Acesso</span>
        </div>
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-foreground">
          Segurança
        </h2>
        <p className="text-xs sm:text-sm text-muted leading-relaxed">
          Gerencie o acesso ao painel administrativo da pizzaria. A proteção das rotas é validada e criptografada de forma segura no backend.
        </p>
      </div>

      {/* Success Notification */}
      {successMessage && (
        <div className="p-4 sm:p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3.5 text-xs sm:text-sm text-emerald-400 shadow-xl animate-fade-in">
          <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-semibold block">Sucesso!</span>
            <span>{successMessage}</span>
          </div>
        </div>
      )}

      {/* Change Password Card */}
      <div className="bg-surface rounded-2xl border border-surface-border p-6 sm:p-8 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-surface-border">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-foreground font-semibold text-base">
              <Lock className="w-4 h-4 text-primary" />
              <span>Senha de Acesso ao Painel</span>
            </div>
            <p className="text-xs text-muted max-w-lg leading-relaxed">
              Altere a senha utilizada para desbloquear o painel administrativo. Por motivos de segurança, é necessária a senha de autorização administrativa.
            </p>
          </div>

          {!isFormOpen && (
            <button
              onClick={handleOpenForm}
              className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-wider font-semibold transition-colors shadow-lg shadow-primary/20 shrink-0 cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              <span>Alterar senha do painel</span>
            </button>
          )}
        </div>

        {/* Change Password Form (Modal or Inline Accordion) */}
        {isFormOpen && (
          <div className="bg-secondary/70 border border-primary/20 rounded-2xl p-6 sm:p-7 space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <KeyRound className="w-4 h-4 text-primary" />
                <span>Formulário de Alteração de Senha</span>
              </div>
              <button
                type="button"
                onClick={handleCloseForm}
                className="text-muted hover:text-foreground p-1 transition-colors cursor-pointer"
                aria-label="Fechar formulário"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {error && (
              <div className="p-3.5 rounded-lg bg-primary/10 border border-primary/30 flex items-start gap-2.5 text-xs text-primary font-medium">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Field 1: Senha de autorização para alteração */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-medium text-foreground">
                    1. Senha de autorização para alteração *
                  </label>
                  <span className="text-[11px] font-mono text-muted">
                    Exigido para autorizar a troca
                  </span>
                </div>
                <div className="relative">
                  <input
                    type={showAuthPass ? 'text' : 'password'}
                    value={authPassword}
                    onChange={(e) => {
                      setAuthPassword(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="Digite a senha de autorização..."
                    required
                    className="w-full pl-3.5 pr-11 py-2.5 rounded-lg bg-surface border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAuthPass(!showAuthPass)}
                    aria-label={showAuthPass ? 'Ocultar senha' : 'Ver senha'}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-foreground p-1 cursor-pointer"
                  >
                    {showAuthPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p className="text-[11px] text-muted">
                  A senha de autorização valida a permissão para definir uma nova senha e nunca permite login direto no painel.
                </p>
              </div>

              {/* Field 2: Nova senha de acesso ao painel */}
              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-foreground">
                  2. Nova senha de acesso ao painel *
                </label>
                <div className="relative">
                  <input
                    type={showNewPass ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => {
                      setNewPassword(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="Mínimo 6 caracteres..."
                    required
                    className="w-full pl-3.5 pr-11 py-2.5 rounded-lg bg-surface border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPass(!showNewPass)}
                    aria-label={showNewPass ? 'Ocultar senha' : 'Ver senha'}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-foreground p-1 cursor-pointer"
                  >
                    {showNewPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Field 3: Confirmar nova senha */}
              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-foreground">
                  3. Confirmar nova senha *
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPass ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="Repita a nova senha..."
                    required
                    className="w-full pl-3.5 pr-11 py-2.5 rounded-lg bg-surface border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPass(!showConfirmPass)}
                    aria-label={showConfirmPass ? 'Ocultar senha' : 'Ver senha'}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-foreground p-1 cursor-pointer"
                  >
                    {showConfirmPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleCloseForm}
                  disabled={loading}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-lg border border-surface-border text-xs text-muted hover:text-foreground transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-lg bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-wider font-semibold transition-colors shadow-lg shadow-primary/20 cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{loading ? 'Salvando...' : 'Confirmar e Atualizar Senha'}</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Security Overview Footer */}
        <div className="p-4 rounded-xl bg-secondary border border-surface-border text-xs text-muted space-y-1.5">
          <div className="flex items-center gap-2 text-foreground font-semibold">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Proteção Ativa</span>
          </div>
          <p className="leading-relaxed text-[11px]">
            As senhas são criptografadas e persistidas no servidor através do algoritmo PBKDF2 com salt seguro. Nenhuma senha trafega descriptografada ou permanece exposta em código JavaScript no navegador.
          </p>
        </div>
      </div>
    </div>
  );
};
