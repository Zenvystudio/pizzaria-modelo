import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Check, AlertCircle, ArrowUpDown, Eye, EyeOff } from 'lucide-react';
import { CategoryItem } from '../../types';
import { addCategory, updateCategory, deleteCategory } from '../../services/categoryService';

interface CategoriesTabProps {
  categories: CategoryItem[];
}

export const CategoriesTab: React.FC<CategoriesTabProps> = ({ categories }) => {
  const [editingCategory, setEditingCategory] = useState<CategoryItem | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [order, setOrder] = useState<number>(1);
  const [isActive, setIsActive] = useState(true);
  const [loading, setLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleOpenCreate = () => {
    setName('');
    setDescription('');
    setOrder(categories.length + 1);
    setIsActive(true);
    setIsCreating(true);
    setEditingCategory(null);
  };

  const handleOpenEdit = (cat: CategoryItem) => {
    setName(cat.name);
    setDescription(cat.description || '');
    setOrder(cat.order);
    setIsActive(cat.isActive !== false);
    setEditingCategory(cat);
    setIsCreating(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Nome da categoria é obrigatório.');
      return;
    }

    setLoading(true);
    try {
      if (isCreating) {
        await addCategory({
          name: name.trim(),
          description: description.trim(),
          order: Number(order) || 1,
          isActive,
        });
        showToast('Categoria criada com sucesso!');
      } else if (editingCategory) {
        await updateCategory(editingCategory.id, {
          name: name.trim(),
          description: description.trim(),
          order: Number(order) || 1,
          isActive,
        });
        showToast('Categoria atualizada!');
      }
      setIsCreating(false);
      setEditingCategory(null);
    } catch (err) {
      console.error(err);
      alert('Erro ao salvar categoria.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (cat: CategoryItem) => {
    if (confirm(`Tem certeza que deseja excluir a categoria "${cat.name}"?`)) {
      const res = await deleteCategory(cat.id);
      if (!res.success) {
        alert(res.error || 'Não foi possível excluir esta categoria.');
      } else {
        showToast('Categoria excluída com sucesso.');
      }
    }
  };

  const handleToggleActive = async (cat: CategoryItem) => {
    try {
      await updateCategory(cat.id, { isActive: !cat.isActive });
      showToast(`Categoria ${!cat.isActive ? 'ativada' : 'desativada'}.`);
    } catch (err) {
      console.error(err);
      alert('Erro ao atualizar status da categoria.');
    }
  };

  return (
    <div className="space-y-6">
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 p-4 rounded-xl bg-emerald-600 text-white text-xs font-semibold shadow-2xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-surface p-6 rounded-2xl border border-surface-border">
        <div>
          <h2 className="font-display text-2xl font-bold text-foreground">
            Gerenciamento de Categorias
          </h2>
          <p className="text-xs text-muted">
            Defina a ordem e as seções exibidas no cardápio dos clientes.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-wider font-semibold transition-colors shadow-sm cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Nova Categoria</span>
        </button>
      </div>

      {/* Categories Table */}
      <div className="rounded-2xl bg-surface border border-surface-border overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-secondary/60 text-muted uppercase tracking-wider font-mono border-b border-surface-border">
              <tr>
                <th className="py-3.5 px-6">Ordem</th>
                <th className="py-3.5 px-6">Categoria</th>
                <th className="py-3.5 px-6">Descrição</th>
                <th className="py-3.5 px-6">Status</th>
                <th className="py-3.5 px-6 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {categories.map((cat) => (
                <tr key={cat.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="py-4 px-6 font-mono font-bold text-muted text-sm tabular-nums">
                    #{cat.order}
                  </td>
                  <td className="py-4 px-6 font-display text-base font-bold text-foreground">
                    {cat.name}
                  </td>
                  <td className="py-4 px-6 text-muted max-w-sm">
                    {cat.description || '—'}
                  </td>
                  <td className="py-4 px-6">
                    <button
                      onClick={() => handleToggleActive(cat)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold cursor-pointer border ${
                        cat.isActive
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                          : 'bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20'
                      }`}
                    >
                      {cat.isActive ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      <span>{cat.isActive ? 'Ativa' : 'Inativa'}</span>
                    </button>
                  </td>
                  <td className="py-4 px-6 text-right space-x-2">
                    <button
                      onClick={() => handleOpenEdit(cat)}
                      className="p-2 rounded-lg bg-surface-hover hover:bg-secondary text-foreground transition-colors cursor-pointer"
                      title="Editar categoria"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(cat)}
                      className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-colors cursor-pointer"
                      title="Excluir categoria"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal create / edit */}
      {(isCreating || editingCategory) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => {
              setIsCreating(false);
              setEditingCategory(null);
            }}
          />

          <div className="relative w-full max-w-md bg-surface border border-surface-border rounded-2xl p-6 md:p-8 space-y-6 shadow-2xl z-10">
            <div className="flex items-center justify-between pb-4 border-b border-surface-border">
              <h3 className="font-display text-2xl font-bold text-foreground">
                {isCreating ? 'Nova Categoria' : `Editar ${editingCategory?.name}`}
              </h3>
              <button
                onClick={() => {
                  setIsCreating(false);
                  setEditingCategory(null);
                }}
                className="p-2 text-muted hover:text-foreground"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-foreground">
                  Nome da Categoria *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: Pizzas Doces, Calzones..."
                  required
                  className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-sm focus:outline-none focus:border-primary"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-foreground">
                  Ordem de Exibição
                </label>
                <input
                  type="number"
                  min="1"
                  value={order}
                  onChange={(e) => setOrder(parseInt(e.target.value) || 1)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-sm font-mono focus:outline-none focus:border-primary"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-foreground">
                  Descrição (opcional)
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Breve descrição da categoria..."
                  className="w-full px-3.5 py-2 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary resize-none"
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer p-3 rounded-lg bg-secondary border border-surface-border">
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="rounded text-primary focus:ring-primary"
                />
                <span className="text-xs font-semibold text-foreground">Categoria Ativa no Cardápio</span>
              </label>

              <div className="pt-4 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsCreating(false);
                    setEditingCategory(null);
                  }}
                  className="px-4 py-2.5 rounded-lg bg-surface-hover hover:bg-secondary text-foreground text-xs font-semibold border border-surface-border cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2.5 rounded-lg bg-primary hover:bg-primary-hover text-white text-xs font-semibold uppercase tracking-wider cursor-pointer shadow-lg shadow-primary/20 disabled:opacity-50"
                >
                  {loading ? 'Salvando...' : 'Salvar Categoria'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
