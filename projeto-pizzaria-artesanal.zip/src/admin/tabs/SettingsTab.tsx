import React, { useState } from 'react';
import { Store, Check, Save, Clock, MapPin, Phone, DollarSign, AlertTriangle } from 'lucide-react';
import { PizzeriaSettings } from '../../types';
import { updatePizzeriaSettings } from '../../services/settingsService';

interface SettingsTabProps {
  settings: PizzeriaSettings;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({ settings }) => {
  const [pizzeriaName, setPizzeriaName] = useState(settings.pizzeriaName);
  const [phone, setPhone] = useState(settings.phone);
  const [whatsapp, setWhatsapp] = useState(settings.whatsapp);
  const [address, setAddress] = useState(settings.address);
  const [defaultDeliveryFee, setDefaultDeliveryFee] = useState(settings.defaultDeliveryFee.toString());
  const [estimatedDeliveryTime, setEstimatedDeliveryTime] = useState(settings.estimatedDeliveryTime);
  const [minimumOrder, setMinimumOrder] = useState(settings.minimumOrder.toString());
  const [isOpen, setIsOpen] = useState(settings.isOpen);
  const [closedMessage, setClosedMessage] = useState(settings.closedMessage);
  const [acceptedPayments, setAcceptedPayments] = useState(settings.acceptedPayments);
  const [instagram, setInstagram] = useState(settings.instagram || '');
  const [loading, setLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updatePizzeriaSettings({
        pizzeriaName: pizzeriaName.trim(),
        phone: phone.trim(),
        whatsapp: whatsapp.trim(),
        address: address.trim(),
        defaultDeliveryFee: parseFloat(defaultDeliveryFee.replace(',', '.')) || 0,
        estimatedDeliveryTime: estimatedDeliveryTime.trim(),
        minimumOrder: parseFloat(minimumOrder.replace(',', '.')) || 0,
        isOpen,
        closedMessage: closedMessage.trim(),
        acceptedPayments: acceptedPayments.trim(),
        instagram: instagram.trim(),
      });
      setToastMessage('Configurações salvas e aplicadas ao site público!');
      setTimeout(() => setToastMessage(null), 3000);
    } catch (err) {
      console.error(err);
      alert('Erro ao salvar configurações.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 p-4 rounded-xl bg-emerald-600 text-white text-xs font-semibold shadow-2xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="bg-surface p-6 rounded-2xl border border-surface-border">
        <h2 className="font-display text-2xl font-bold text-foreground">
          Configurações Operacionais
        </h2>
        <p className="text-xs text-muted">
          Gerencie status de funcionamento, taxas, prazos de entrega e dados de contato.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        {/* Open / Closed Switch Card */}
        <div className="p-6 rounded-2xl bg-surface border border-surface-border space-y-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-mono uppercase tracking-wider text-muted">Status do Forno</span>
              <div className="text-lg font-bold text-foreground">
                Pizzaria {isOpen ? 'Aberta para Pedidos' : 'Fechada Temporariamente'}
              </div>
              <p className="text-xs text-muted">
                {isOpen
                  ? 'Os clientes conseguem montar pizzas e enviar pedidos para o WhatsApp normalmente.'
                  : 'O site apresentará aviso de fechado e impedirá novos pedidos.'}
              </p>
            </div>

            <button
              type="button"
              onClick={() => setIsOpen(!isOpen)}
              className={`px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer border ${
                isOpen
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                  : 'bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20'
              }`}
            >
              {isOpen ? 'Forno Aberto' : 'Forno Fechado'}
            </button>
          </div>

          {!isOpen && (
            <div className="space-y-1.5 pt-2">
              <label className="block text-xs font-medium text-foreground">
                Mensagem exibida aos clientes quando fechado:
              </label>
              <textarea
                rows={2}
                value={closedMessage}
                onChange={(e) => setClosedMessage(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary resize-none"
              />
            </div>
          )}
        </div>

        {/* Business details */}
        <div className="p-6 rounded-2xl bg-surface border border-surface-border space-y-6 shadow-lg">
          <h3 className="font-display text-xl font-bold text-foreground">
            Dados da Pizzaria & Contato
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-foreground">
                Nome do Estabelecimento
              </label>
              <input
                type="text"
                value={pizzeriaName}
                onChange={(e) => setPizzeriaName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-foreground">
                Telefone de Atendimento
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs font-mono focus:outline-none focus:border-primary"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-foreground">
                Número do WhatsApp (com DDD)
              </label>
              <input
                type="text"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs font-mono focus:outline-none focus:border-primary"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-foreground">
                Instagram Oficial
              </label>
              <input
                type="text"
                value={instagram}
                onChange={(e) => setInstagram(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-foreground">
              Endereço Físico Completo
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary"
            />
          </div>
        </div>

        {/* Operational delivery parameters */}
        <div className="p-6 rounded-2xl bg-surface border border-surface-border space-y-6 shadow-lg">
          <h3 className="font-display text-xl font-bold text-foreground">
            Parâmetros de Entrega & Pagamento
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-foreground">
                Taxa de Entrega Padrão (R$)
              </label>
              <input
                type="text"
                value={defaultDeliveryFee}
                onChange={(e) => setDefaultDeliveryFee(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs font-mono focus:outline-none focus:border-primary"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-foreground">
                Tempo Estimado de Entrega
              </label>
              <input
                type="text"
                value={estimatedDeliveryTime}
                onChange={(e) => setEstimatedDeliveryTime(e.target.value)}
                placeholder="Ex: 40-50 min"
                className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-foreground">
                Valor Mínimo do Pedido (R$)
              </label>
              <input
                type="text"
                value={minimumOrder}
                onChange={(e) => setMinimumOrder(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs font-mono focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-foreground">
              Formas de Pagamento Aceitas (visíveis ao cliente)
            </label>
            <input
              type="text"
              value={acceptedPayments}
              onChange={(e) => setAcceptedPayments(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary"
            />
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-md bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-widest font-semibold transition-colors shadow-lg shadow-primary/20 cursor-pointer disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{loading ? 'Salvando...' : 'Salvar Todas as Configurações'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
