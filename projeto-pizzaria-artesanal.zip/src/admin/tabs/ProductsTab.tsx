import React, { useState } from 'react';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Check,
  X,
  AlertCircle,
  Eye,
  EyeOff,
  Star,
  DollarSign,
  Sparkles,
} from 'lucide-react';
import { MenuItem, CategoryItem } from '../../types';
import {
  addProduct,
  updateProduct,
  deleteProduct,
  toggleProductAvailability,
  updateProductPrice,
} from '../../services/productService';

interface ProductsTabProps {
  products: MenuItem[];
  categories: CategoryItem[];
}

export const ProductsTab: React.FC<ProductsTabProps> = ({ products, categories }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('todos');
  const [editingProduct, setEditingProduct] = useState<MenuItem | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [priceEditingId, setPriceEditingId] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Form states for create/edit
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formPrice, setFormPrice] = useState('');
  const [formImage, setFormImage] = useState('');
  const [formHighlight, setFormHighlight] = useState(false);
  const [formAvailable, setFormAvailable] = useState(true);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleOpenCreate = () => {
    setFormName('');
    setFormCategory(categories[0]?.id || 'classicas');
    setFormDescription('');
    setFormPrice('');
    setFormImage('');
    setFormHighlight(false);
    setFormAvailable(true);
    setIsCreating(true);
    setEditingProduct(null);
  };

  const handleOpenEdit = (p: MenuItem) => {
    setFormName(p.name);
    setFormCategory(p.category);
    setFormDescription(p.description);
    setFormPrice(p.price.toString());
    setFormImage(p.image || '');
    setFormHighlight(Boolean(p.highlight));
    setFormAvailable(p.isAvailable !== false);
    setEditingProduct(p);
    setIsCreating(false);
  };

  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formPrice) {
      alert('Nome e preço são obrigatórios.');
      return;
    }

    setLoading(true);
    try {
      const parsedPrice = parseFloat(formPrice.replace(',', '.'));
      if (isNaN(parsedPrice) || parsedPrice <= 0) {
        alert('Informe um preço válido.');
        setLoading(false);
        return;
      }

      if (isCreating) {
        await addProduct({
          name: formName.trim(),
          category: formCategory,
          description: formDescription.trim(),
          price: parsedPrice,
          image: formImage.trim() || undefined,
          highlight: formHighlight,
          isAvailable: formAvailable,
        });
        showToast('Produto adicionado ao cardápio com sucesso!');
      } else if (editingProduct) {
        await updateProduct(editingProduct.id, {
          name: formName.trim(),
          category: formCategory,
          description: formDescription.trim(),
          price: parsedPrice,
          image: formImage.trim() || undefined,
          highlight: formHighlight,
          isAvailable: formAvailable,
        });
        showToast('Produto atualizado com sucesso!');
      }

      setIsCreating(false);
      setEditingProduct(null);
    } catch (err) {
      console.error(err);
      alert('Erro ao salvar produto no banco de dados.');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleAvailable = async (p: MenuItem) => {
    try {
      const nextState = p.isAvailable === false ? true : false;
      await toggleProductAvailability(p.id, nextState);
      showToast(`Produto marcado como ${nextState ? 'Disponível' : 'Indisponível'}.`);
    } catch (err) {
      console.error(err);
      alert('Erro ao alterar disponibilidade.');
    }
  };

  const handleDelete = async (p: MenuItem) => {
    if (confirm(`Tem certeza que deseja excluir "${p.name}" do cardápio? O histórico de pedidos antigos será preservado.`)) {
      try {
        await deleteProduct(p.id);
        showToast('Produto removido.');
      } catch (err) {
        console.error(err);
        alert('Erro ao excluir produto.');
      }
    }
  };

  const handleSaveInlinePrice = async (id: string) => {
    const parsed = parseFloat(tempPrice.replace(',', '.'));
    if (isNaN(parsed) || parsed <= 0) {
      alert('Preço inválido.');
      return;
    }
    try {
      await updateProductPrice(id, parsed);
      setPriceEditingId(null);
      showToast('Preço atualizado no cardápio!');
    } catch (err) {
      console.error(err);
      alert('Erro ao atualizar preço.');
    }
  };

  const filtered = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'todos' || p.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 p-4 rounded-xl bg-emerald-600 text-white text-xs font-semibold shadow-2xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header with Search and Create Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-surface p-6 rounded-2xl border border-surface-border">
        <div>
          <h2 className="font-display text-2xl font-bold text-foreground">
            Cardápio & Produtos
          </h2>
          <p className="text-xs text-muted">
            Cadastre novos sabores, edite descrições, ajuste preços e controle a disponibilidade.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary hover:bg-primary-hover text-white text-xs uppercase tracking-wider font-semibold transition-colors shadow-sm cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Novo Produto</span>
        </button>
      </div>

      {/* Filters and search */}
      <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between bg-surface p-4 rounded-xl border border-surface-border">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-muted absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por nome ou ingrediente..."
            className="w-full pl-10 pr-4 py-2 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary transition-colors"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setCategoryFilter('todos')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer ${
              categoryFilter === 'todos' ? 'bg-primary text-white' : 'bg-secondary text-muted hover:text-foreground'
            }`}
          >
            Todas
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer ${
                categoryFilter === cat.id ? 'bg-primary text-white' : 'bg-secondary text-muted hover:text-foreground'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Product List Table */}
      <div className="rounded-2xl bg-surface border border-surface-border overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-secondary/60 text-muted uppercase tracking-wider font-mono border-b border-surface-border">
              <tr>
                <th className="py-3.5 px-6">Produto</th>
                <th className="py-3.5 px-6">Categoria</th>
                <th className="py-3.5 px-6">Preço</th>
                <th className="py-3.5 px-6">Disponibilidade</th>
                <th className="py-3.5 px-6">Destaque</th>
                <th className="py-3.5 px-6 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {filtered.map((product) => {
                const isAvailable = product.isAvailable !== false;
                const isEditingPrice = priceEditingId === product.id;

                return (
                  <tr key={product.id} className="hover:bg-secondary/30 transition-colors">
                    {/* Name & Image */}
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        {product.image ? (
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-11 h-11 rounded-lg object-cover border border-surface-border shrink-0"
                          />
                        ) : (
                          <div className="w-11 h-11 rounded-lg bg-secondary border border-surface-border flex items-center justify-center font-display text-sm font-bold text-muted shrink-0">
                            🍕
                          </div>
                        )}
                        <div>
                          <div className="font-display text-sm font-bold text-foreground">
                            {product.name}
                          </div>
                          <div className="text-[11px] text-muted max-w-xs truncate">
                            {product.description}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Category */}
                    <td className="py-4 px-6 text-muted font-mono uppercase text-[11px]">
                      {categories.find((c) => c.id === product.category)?.name || product.category}
                    </td>

                    {/* Price with In-line Edit */}
                    <td className="py-4 px-6 font-mono font-bold text-foreground tabular-nums">
                      {isEditingPrice ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={tempPrice}
                            onChange={(e) => setTempPrice(e.target.value)}
                            className="w-20 px-2 py-1 rounded bg-secondary border border-primary text-foreground text-xs"
                            autoFocus
                          />
                          <button
                            onClick={() => handleSaveInlinePrice(product.id)}
                            className="p-1 text-emerald-400 hover:text-emerald-300"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setPriceEditingId(null)}
                            className="p-1 text-muted hover:text-foreground"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            setPriceEditingId(product.id);
                            setTempPrice(product.price.toFixed(2));
                          }}
                          className="hover:text-primary transition-colors cursor-pointer group flex items-center gap-1"
                          title="Clique para editar preço rápido"
                        >
                          <span>R$ {product.price.toFixed(2).replace('.', ',')}</span>
                          <Edit2 className="w-3 h-3 text-muted opacity-0 group-hover:opacity-100 transition-opacity" />
                        </button>
                      )}
                    </td>

                    {/* Availability Switch */}
                    <td className="py-4 px-6">
                      <button
                        onClick={() => handleToggleAvailable(product)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold transition-colors cursor-pointer border ${
                          isAvailable
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                            : 'bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20'
                        }`}
                      >
                        {isAvailable ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                        <span>{isAvailable ? 'Disponível' : 'Indisponível'}</span>
                      </button>
                    </td>

                    {/* Highlight */}
                    <td className="py-4 px-6">
                      {product.highlight ? (
                        <span className="inline-flex items-center gap-1 text-[11px] text-amber-400 font-semibold font-mono">
                          <Star className="w-3.5 h-3.5 fill-amber-400" />
                          <span>Destaque</span>
                        </span>
                      ) : (
                        <span className="text-muted/50 text-[11px] font-mono">—</span>
                      )}
                    </td>

                    {/* Action buttons */}
                    <td className="py-4 px-6 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(product)}
                        className="p-2 rounded-lg bg-surface-hover hover:bg-secondary text-foreground transition-colors cursor-pointer"
                        title="Editar produto"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(product)}
                        className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-colors cursor-pointer"
                        title="Excluir produto"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {(isCreating || editingProduct) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
            onClick={() => {
              setIsCreating(false);
              setEditingProduct(null);
            }}
          />

          <div className="relative w-full max-w-lg bg-surface border border-surface-border rounded-2xl p-6 md:p-8 space-y-6 shadow-2xl z-10">
            <div className="flex items-center justify-between pb-4 border-b border-surface-border">
              <h3 className="font-display text-2xl font-bold text-foreground">
                {isCreating ? 'Adicionar Novo Produto' : `Editar ${editingProduct?.name}`}
              </h3>
              <button
                onClick={() => {
                  setIsCreating(false);
                  setEditingProduct(null);
                }}
                className="p-2 text-muted hover:text-foreground"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-foreground">
                  Nome do Produto *
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="Ex: Margherita Speciale"
                  required
                  className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-sm focus:outline-none focus:border-primary"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-foreground">
                    Categoria *
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary font-semibold"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-foreground">
                    Preço (R$) *
                  </label>
                  <input
                    type="text"
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    placeholder="Ex: 72,00"
                    required
                    className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-sm font-mono focus:outline-none focus:border-primary"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-foreground">
                  Descrição e Ingredientes
                </label>
                <textarea
                  rows={3}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Molho artesanal, mozzarella fresca, orégano..."
                  className="w-full px-3.5 py-2 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary resize-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-foreground">
                  URL da Imagem
                </label>
                <input
                  type="text"
                  value={formImage}
                  onChange={(e) => setFormImage(e.target.value)}
                  placeholder="/src/assets/images/... ou URL HTTPS"
                  className="w-full px-3.5 py-2 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <label className="flex items-center gap-2 cursor-pointer p-3 rounded-lg bg-secondary border border-surface-border">
                  <input
                    type="checkbox"
                    checked={formAvailable}
                    onChange={(e) => setFormAvailable(e.target.checked)}
                    className="rounded text-primary focus:ring-primary"
                  />
                  <span className="text-xs font-semibold text-foreground">Disponível para Pedidos</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer p-3 rounded-lg bg-secondary border border-surface-border">
                  <input
                    type="checkbox"
                    checked={formHighlight}
                    onChange={(e) => setFormHighlight(e.target.checked)}
                    className="rounded text-primary focus:ring-primary"
                  />
                  <span className="text-xs font-semibold text-foreground">Destaque na Página</span>
                </label>
              </div>

              <div className="pt-4 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsCreating(false);
                    setEditingProduct(null);
                  }}
                  className="px-4 py-2.5 rounded-lg bg-surface-hover hover:bg-secondary text-foreground text-xs font-semibold border border-surface-border cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2.5 rounded-lg bg-primary hover:bg-primary-hover text-white text-xs font-semibold uppercase tracking-wider cursor-pointer shadow-lg shadow-primary/20 disabled:opacity-50"
                >
                  {loading ? 'Salvando...' : 'Salvar Alterações'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
