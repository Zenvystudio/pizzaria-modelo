import React, { useState } from 'react';
import {
  Search,
  Filter,
  Check,
  Clock,
  Bike,
  CheckCircle2,
  XCircle,
  ExternalLink,
  MessageCircle,
  ChevronRight,
  Flame,
  AlertTriangle,
} from 'lucide-react';
import { Order, OrderStatus, PaymentStatus } from '../../types';
import { updateOrderStatus, updateOrderPaymentStatus } from '../../services/orderService';

interface OrdersTabProps {
  orders: Order[];
  selectedOrder: Order | null;
  onSelectOrder: (order: Order | null) => void;
}

export const OrdersTab: React.FC<OrdersTabProps> = ({
  orders,
  selectedOrder,
  onSelectOrder,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [loadingAction, setLoadingAction] = useState<string | null>(null);

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerPhone.includes(searchTerm);

    if (statusFilter === 'todos') return matchesSearch;
    return matchesSearch && order.status === statusFilter;
  });

  const handleStatusChange = async (orderId: string, newStatus: OrderStatus) => {
    setLoadingAction(orderId);
    try {
      await updateOrderStatus(orderId, newStatus);
      if (selectedOrder && selectedOrder.id === orderId) {
        onSelectOrder({ ...selectedOrder, status: newStatus });
      }
    } catch (err) {
      console.error(err);
      alert('Erro ao atualizar status do pedido.');
    } finally {
      setLoadingAction(null);
    }
  };

  const handlePaymentChange = async (orderId: string, newPaymentStatus: PaymentStatus) => {
    setLoadingAction(orderId);
    try {
      await updateOrderPaymentStatus(orderId, newPaymentStatus);
      if (selectedOrder && selectedOrder.id === orderId) {
        onSelectOrder({ ...selectedOrder, paymentStatus: newPaymentStatus });
      }
    } catch (err) {
      console.error(err);
      alert('Erro ao atualizar status de pagamento.');
    } finally {
      setLoadingAction(null);
    }
  };

  const newOrdersCount = orders.filter((o) => o.status === 'novo').length;

  return (
    <div className="space-y-6">
      {/* Visual notification for new incoming orders */}
      {newOrdersCount > 0 && (
        <div className="p-4 rounded-xl bg-primary/20 border border-primary/50 text-foreground flex items-center justify-between gap-4 animate-pulse">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xs">
              {newOrdersCount}
            </div>
            <div>
              <span className="font-bold text-sm">
                {newOrdersCount === 1 ? 'Novo pedido aguardando confirmação!' : `${newOrdersCount} novos pedidos aguardando confirmação!`}
              </span>
              <p className="text-xs text-muted">Confirme com a cozinha para iniciar a massa.</p>
            </div>
          </div>
          <button
            onClick={() => setStatusFilter('novo')}
            className="px-3.5 py-1.5 rounded-lg bg-primary text-white font-semibold text-xs hover:bg-primary-hover transition-colors cursor-pointer"
          >
            Filtrar Novos
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-stretch md:items-center bg-surface p-4 rounded-xl border border-surface-border">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-muted absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por #pedido, nome ou telefone..."
            className="w-full pl-10 pr-4 py-2 rounded-lg bg-secondary border border-surface-border text-foreground text-xs focus:outline-none focus:border-primary transition-colors"
          />
        </div>

        {/* Status Filters */}
        <div className="flex flex-wrap gap-1.5">
          {[
            { id: 'todos', label: 'Todos' },
            { id: 'novo', label: 'Novos' },
            { id: 'confirmado', label: 'Confirmados' },
            { id: 'em_preparacao', label: 'No Forno' },
            { id: 'pronto', label: 'Prontos' },
            { id: 'saiu_para_entrega', label: 'Em Entrega' },
            { id: 'concluido', label: 'Concluídos' },
            { id: 'cancelado', label: 'Cancelados' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                statusFilter === tab.id
                  ? 'bg-primary text-white shadow-sm'
                  : 'bg-secondary text-muted hover:text-foreground'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Orders Grid/List */}
      {filteredOrders.length === 0 ? (
        <div className="p-16 text-center bg-surface rounded-2xl border border-surface-border space-y-2">
          <div className="text-sm text-muted">Nenhum pedido encontrado para este filtro.</div>
          <div className="text-xs text-muted/60">Tente buscar por outro termo ou selecione Todos.</div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredOrders.map((order) => {
            const isNew = order.status === 'novo';
            const cleanPhone = order.customerPhone.replace(/\D/g, '');
            const customerWaUrl = `https://wa.me/55${cleanPhone}?text=Ol%C3%A1%20${encodeURIComponent(
              order.customerName
            )}%2C%20falamos%20da%20Pizzaria%20sobre%20seu%20pedido%20%23${order.id}.`;

            return (
              <div
                key={order.id}
                className={`p-6 rounded-2xl bg-surface border transition-all ${
                  isNew
                    ? 'border-primary/60 shadow-lg shadow-primary/10'
                    : 'border-surface-border hover:border-surface-hover'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                  {/* Info Column */}
                  <div className="space-y-2 flex-1">
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="font-mono text-base font-bold text-foreground">
                        #{order.id}
                      </span>
                      <span className="text-xs text-muted font-mono">
                        {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-secondary text-muted uppercase">
                        {order.orderType === 'entrega' ? 'Delivery' : order.orderType === 'retirada' ? 'Balcão' : 'Mesa'}
                      </span>
                      <span
                        className={`text-[11px] font-mono px-2 py-0.5 rounded uppercase font-semibold ${
                          order.paymentStatus === 'confirmado'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-amber-500/20 text-amber-400'
                        }`}
                      >
                        Pagamento: {order.paymentStatus} ({order.paymentMethod.replace('_', ' ')})
                      </span>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-base font-semibold text-foreground">
                        {order.customerName}
                      </div>
                      <a
                        href={customerWaUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-emerald-400 hover:text-emerald-300 font-mono flex items-center gap-1 transition-colors"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>{order.customerPhone}</span>
                      </a>
                    </div>

                    {order.deliveryAddress && (
                      <div className="text-xs text-muted">
                        <span className="font-semibold text-foreground/80">Endereço:</span> {order.deliveryAddress}
                      </div>
                    )}

                    <div className="text-xs text-muted pt-1">
                      <span className="font-semibold text-foreground/80">Itens:</span>{' '}
                      {order.items.map((i) => `${i.quantity}x ${i.name}`).join(' · ')}
                    </div>

                    {order.notes && (
                      <div className="text-xs text-amber-400/90 bg-amber-500/10 p-2 rounded-lg border border-amber-500/20 max-w-lg">
                        <span className="font-semibold">Obs:</span> {order.notes}
                      </div>
                    )}
                  </div>

                  {/* Pricing and Actions Column */}
                  <div className="flex flex-col sm:flex-row lg:flex-col items-start lg:items-end justify-between gap-4 shrink-0">
                    <div className="text-left lg:text-right">
                      <div className="text-[11px] text-muted font-mono uppercase">Total do Pedido</div>
                      <div className="font-mono text-2xl font-bold text-foreground tabular-nums">
                        R$ {order.total.toFixed(2).replace('.', ',')}
                      </div>
                    </div>

                    {/* Quick Status Buttons Progression */}
                    <div className="flex flex-wrap items-center gap-2">
                      {order.status === 'novo' && (
                        <button
                          onClick={() => handleStatusChange(order.id, 'confirmado')}
                          disabled={loadingAction === order.id}
                          className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors cursor-pointer shadow-sm"
                        >
                          Confirmar
                        </button>
                      )}

                      {(order.status === 'novo' || order.status === 'confirmado') && (
                        <button
                          onClick={() => handleStatusChange(order.id, 'em_preparacao')}
                          disabled={loadingAction === order.id}
                          className="px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <Flame className="w-3.5 h-3.5" />
                          <span>No Forno</span>
                        </button>
                      )}

                      {order.status === 'em_preparacao' && (
                        <button
                          onClick={() => handleStatusChange(order.id, 'pronto')}
                          disabled={loadingAction === order.id}
                          className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors cursor-pointer"
                        >
                          Pronto
                        </button>
                      )}

                      {order.status === 'pronto' && order.orderType === 'entrega' && (
                        <button
                          onClick={() => handleStatusChange(order.id, 'saiu_para_entrega')}
                          disabled={loadingAction === order.id}
                          className="px-3.5 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <Bike className="w-3.5 h-3.5" />
                          <span>Saiu p/ Entrega</span>
                        </button>
                      )}

                      {(order.status === 'saiu_para_entrega' || order.status === 'pronto') && (
                        <button
                          onClick={() => handleStatusChange(order.id, 'concluido')}
                          disabled={loadingAction === order.id}
                          className="px-3.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-semibold transition-colors cursor-pointer"
                        >
                          Concluir
                        </button>
                      )}

                      {order.status !== 'cancelado' && order.status !== 'concluido' && (
                        <button
                          onClick={() => {
                            if (confirm(`Deseja realmente cancelar o pedido #${order.id}?`)) {
                              handleStatusChange(order.id, 'cancelado');
                            }
                          }}
                          disabled={loadingAction === order.id}
                          className="px-2.5 py-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 text-xs font-medium transition-colors cursor-pointer"
                        >
                          Cancelar
                        </button>
                      )}

                      <button
                        onClick={() => onSelectOrder(order)}
                        className="px-3 py-1.5 rounded-lg bg-surface-hover hover:bg-secondary text-foreground text-xs font-medium border border-surface-border transition-colors cursor-pointer"
                      >
                        Ver Detalhes
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal with Full Order Details */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
            onClick={() => onSelectOrder(null)}
            aria-hidden="true"
          />

          <div className="relative w-full max-w-xl bg-surface border border-surface-border rounded-2xl p-6 md:p-8 space-y-6 shadow-2xl z-10">
            <div className="flex items-start justify-between pb-4 border-b border-surface-border">
              <div>
                <span className="font-mono text-xs uppercase text-muted">Comprovante Digital</span>
                <h3 className="font-display text-2xl font-bold text-foreground">
                  Pedido #{selectedOrder.id}
                </h3>
                <div className="text-xs text-muted font-mono mt-1">
                  Registrado em: {new Date(selectedOrder.createdAt).toLocaleString()}
                </div>
              </div>

              <button
                onClick={() => onSelectOrder(null)}
                className="p-2 text-muted hover:text-foreground rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Customer Info */}
            <div className="p-4 rounded-xl bg-secondary border border-surface-border space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-muted">Cliente:</span>
                <span className="font-semibold text-foreground">{selectedOrder.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted">Telefone:</span>
                <span className="font-mono text-foreground">{selectedOrder.customerPhone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted">Modalidade:</span>
                <span className="font-semibold uppercase text-primary">{selectedOrder.orderType}</span>
              </div>
              {selectedOrder.deliveryAddress && (
                <div className="flex justify-between">
                  <span className="text-muted">Endereço de Entrega:</span>
                  <span className="text-foreground text-right max-w-xs">{selectedOrder.deliveryAddress}</span>
                </div>
              )}
            </div>

            {/* Items list */}
            <div className="space-y-3">
              <div className="text-xs font-mono uppercase text-muted">Itens da Comanda</div>
              <div className="divide-y divide-surface-border border border-surface-border rounded-xl p-3 bg-secondary/50">
                {selectedOrder.items.map((item, idx) => (
                  <div key={idx} className="py-2.5 flex justify-between items-center text-xs">
                    <div>
                      <span className="font-semibold text-foreground">{item.quantity}x {item.name}</span>
                      {item.notes && <div className="text-[11px] text-muted italic">{item.notes}</div>}
                    </div>
                    <span className="font-mono tabular-nums text-foreground">
                      R$ {(item.price * item.quantity).toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Totals */}
            <div className="p-4 rounded-xl bg-secondary border border-surface-border space-y-2 text-xs font-mono">
              <div className="flex justify-between text-muted">
                <span>Subtotal:</span>
                <span>R$ {selectedOrder.subtotal.toFixed(2).replace('.', ',')}</span>
              </div>
              <div className="flex justify-between text-muted">
                <span>Taxa de Entrega:</span>
                <span>R$ {selectedOrder.deliveryFee.toFixed(2).replace('.', ',')}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-foreground pt-2 border-t border-surface-border">
                <span>Total a Cobrar:</span>
                <span className="text-primary text-base">R$ {selectedOrder.total.toFixed(2).replace('.', ',')}</span>
              </div>
            </div>

            {/* Payment & Status Control */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono uppercase text-muted">Status do Pedido</label>
                <select
                  value={selectedOrder.status}
                  onChange={(e) => handleStatusChange(selectedOrder.id, e.target.value as OrderStatus)}
                  className="w-full p-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs font-semibold focus:outline-none focus:border-primary"
                >
                  <option value="novo">Novo</option>
                  <option value="confirmado">Confirmado</option>
                  <option value="em_preparacao">Em Preparação</option>
                  <option value="pronto">Pronto</option>
                  <option value="saiu_para_entrega">Saiu para Entrega</option>
                  <option value="concluido">Concluído</option>
                  <option value="cancelado">Cancelado</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] font-mono uppercase text-muted">Status do Pagamento</label>
                <select
                  value={selectedOrder.paymentStatus}
                  onChange={(e) => handlePaymentChange(selectedOrder.id, e.target.value as PaymentStatus)}
                  className="w-full p-2.5 rounded-lg bg-secondary border border-surface-border text-foreground text-xs font-semibold focus:outline-none focus:border-primary"
                >
                  <option value="pendente">Pendente</option>
                  <option value="confirmado">Confirmado</option>
                  <option value="na_entrega">Pagar na Entrega</option>
                </select>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => onSelectOrder(null)}
                className="px-6 py-2.5 rounded-lg bg-surface-hover hover:bg-secondary text-foreground text-xs font-semibold border border-surface-border cursor-pointer transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
