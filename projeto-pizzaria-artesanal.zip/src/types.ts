export interface MenuItem {
  id: string;
  name: string;
  category: string;
  description: string;
  price: number;
  image?: string;
  tags?: string[];
  highlight?: boolean;
  isAvailable?: boolean;
}

export interface CategoryItem {
  id: string;
  name: string;
  description?: string;
  order: number;
  isActive: boolean;
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
  notes?: string;
}

export type OrderStatus =
  | 'novo'
  | 'confirmado'
  | 'em_preparacao'
  | 'pronto'
  | 'saiu_para_entrega'
  | 'concluido'
  | 'cancelado';

export type PaymentMethod =
  | 'pix'
  | 'cartao_credito'
  | 'cartao_debito'
  | 'dinheiro';

export type PaymentStatus = 'pendente' | 'confirmado' | 'na_entrega';

export interface OrderItemSnapshot {
  id: string;
  name: string;
  price: number;
  quantity: number;
  notes?: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  items: OrderItemSnapshot[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  orderType: 'entrega' | 'retirada' | 'mesa';
  deliveryAddress?: string;
  notes?: string;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
}

export interface PizzeriaSettings {
  pizzeriaName: string;
  phone: string;
  whatsapp: string;
  address: string;
  defaultDeliveryFee: number;
  estimatedDeliveryTime: string;
  minimumOrder: number;
  isOpen: boolean;
  closedMessage: string;
  acceptedPayments: string;
  instagram?: string;
  updatedAt?: string;
}

export interface AdminUser {
  uid: string;
  email: string;
  role: 'admin' | 'staff';
  name?: string;
  createdAt?: string;
}

export interface AuthorizedStaff {
  email: string;
  name?: string;
  role: 'admin' | 'staff';
  addedBy?: string;
  createdAt?: string;
}
