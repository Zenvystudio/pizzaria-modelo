import express from 'express';
import crypto from 'crypto';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

const SALT = 'pizzaria_secure_salt_2026';
const SECURITY_FILE = path.resolve(__dirname, 'security-config.json');

// Dedicated authorization password for changing credentials (NEVER grants access to the panel)
const AUTH_PASSWORD_HASH = crypto
  .pbkdf2Sync('senha123', SALT, 10000, 64, 'sha512')
  .toString('hex');

// Initial default panel password hash for 'sitemodelo123'
const DEFAULT_PANEL_PASSWORD_HASH = crypto
  .pbkdf2Sync('sitemodelo123', SALT, 10000, 64, 'sha512')
  .toString('hex');

// Load or initialize persistent password hash
function loadCurrentPasswordHash(): string {
  try {
    if (fs.existsSync(SECURITY_FILE)) {
      const data = JSON.parse(fs.readFileSync(SECURITY_FILE, 'utf8'));
      if (data && data.panelPasswordHash) {
        return data.panelPasswordHash;
      }
    }
  } catch (err) {
    console.warn('Could not read security file, using default:', err);
  }
  return DEFAULT_PANEL_PASSWORD_HASH;
}

function saveCurrentPasswordHash(hash: string): void {
  try {
    fs.writeFileSync(
      SECURITY_FILE,
      JSON.stringify(
        {
          panelPasswordHash: hash,
          updatedAt: new Date().toISOString(),
        },
        null,
        2
      ),
      'utf8'
    );
  } catch (err) {
    console.error('Failed to persist security file:', err);
  }
}

let currentPanelPasswordHash = loadCurrentPasswordHash();

// Active server sessions
const activeSessions = new Map<string, { role: string; expiresAt: number }>();

function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// 1. POST /api/admin/login
// Only accepts the current panel password (initial: sitemodelo123).
// Crucially: 'senha123' is an authorization password and NEVER allows login!
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;

  if (!password || typeof password !== 'string') {
    return res.status(401).json({
      success: false,
      error: 'Senha incorreta. Tente novamente',
    });
  }

  const cleanPass = password.trim();

  // Explicit check: authorization password 'senha123' must NEVER log in
  const authIncomingHash = crypto
    .pbkdf2Sync(cleanPass, SALT, 10000, 64, 'sha512')
    .toString('hex');

  if (
    crypto.timingSafeEqual(
      Buffer.from(authIncomingHash, 'hex'),
      Buffer.from(AUTH_PASSWORD_HASH, 'hex')
    )
  ) {
    return res.status(401).json({
      success: false,
      error: 'Senha incorreta. Tente novamente',
    });
  }

  // Verify against current panel password hash
  const incomingHash = crypto
    .pbkdf2Sync(cleanPass, SALT, 10000, 64, 'sha512')
    .toString('hex');

  const isMatch = crypto.timingSafeEqual(
    Buffer.from(incomingHash, 'hex'),
    Buffer.from(currentPanelPasswordHash, 'hex')
  );

  if (!isMatch) {
    return res.status(401).json({
      success: false,
      error: 'Senha incorreta. Tente novamente',
    });
  }

  // Session valid for 12 hours
  const token = generateToken();
  const expiresAt = Date.now() + 12 * 60 * 60 * 1000;
  activeSessions.set(token, { role: 'admin', expiresAt });

  return res.json({
    success: true,
    token,
    user: {
      role: 'admin',
      name: 'Funcionário Autorizado',
    },
  });
});

// 2. GET /api/admin/session
app.get('/api/admin/session', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ authenticated: false });
  }

  const token = authHeader.substring(7);
  const session = activeSessions.get(token);

  if (!session || session.expiresAt < Date.now()) {
    if (session) activeSessions.delete(token);
    return res.status(401).json({ authenticated: false });
  }

  return res.json({
    authenticated: true,
    user: {
      role: session.role,
      name: 'Funcionário Autorizado',
    },
  });
});

// 3. POST /api/admin/logout
app.post('/api/admin/logout', (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    activeSessions.delete(token);
  }
  return res.json({ success: true });
});

// 4. POST /api/admin/change-password
// Requires active admin session, correct authorization password 'senha123', and matching new passwords
app.post('/api/admin/change-password', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      error: 'Sessão administrativa inválida ou expirada.',
    });
  }

  const token = authHeader.substring(7);
  const session = activeSessions.get(token);
  if (!session || session.expiresAt < Date.now()) {
    if (session) activeSessions.delete(token);
    return res.status(401).json({
      success: false,
      error: 'Sessão administrativa expirada. Faça login novamente.',
    });
  }

  const { authPassword, newPassword, confirmPassword } = req.body;

  if (!authPassword || !newPassword || !confirmPassword) {
    return res.status(400).json({
      success: false,
      error: 'Preencha todos os campos obrigatórios.',
    });
  }

  // 1. Verify authorization password (must match 'senha123')
  const incomingAuthHash = crypto
    .pbkdf2Sync(String(authPassword).trim(), SALT, 10000, 64, 'sha512')
    .toString('hex');

  const isAuthValid = crypto.timingSafeEqual(
    Buffer.from(incomingAuthHash, 'hex'),
    Buffer.from(AUTH_PASSWORD_HASH, 'hex')
  );

  if (!isAuthValid) {
    return res.status(403).json({
      success: false,
      error: 'Senha de autorização incorreta.',
    });
  }

  // 2. Validate matching new passwords
  const cleanNew = String(newPassword).trim();
  const cleanConfirm = String(confirmPassword).trim();

  if (cleanNew !== cleanConfirm) {
    return res.status(400).json({
      success: false,
      error: 'A nova senha e a confirmação não coincidem.',
    });
  }

  if (cleanNew.length < 6) {
    return res.status(400).json({
      success: false,
      error: 'A nova senha deve conter pelo menos 6 caracteres.',
    });
  }

  // 3. Compute new panel password hash and persist
  const newHash = crypto
    .pbkdf2Sync(cleanNew, SALT, 10000, 64, 'sha512')
    .toString('hex');

  currentPanelPasswordHash = newHash;
  saveCurrentPasswordHash(newHash);

  return res.json({
    success: true,
    message: 'Senha do painel alterada com sucesso! A nova senha já está em vigor.',
  });
});

// Mount Vite middleware in development or serve static in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Pizzaria server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
